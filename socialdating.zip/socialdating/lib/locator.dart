import 'package:dio/dio.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get_it/get_it.dart';
import 'package:socialapp/feature/Auth/data/datasources/remote_auth_datasource.dart';
import 'package:socialapp/feature/Auth/data/repository/AuthRepository.dart';
import 'package:socialapp/feature/Auth/domain/repositories/AuthRepositories.dart';
import 'package:socialapp/feature/Auth/domain/usecases/send_otp.dart';
import 'package:socialapp/feature/Auth/domain/usecases/verify_otp.dart';
import 'package:socialapp/feature/Auth/persentation/bloc/auth_bloc.dart';
import 'package:socialapp/feature/post/data/datasources/data_sources_impl.dart';
import 'package:socialapp/feature/story/data/data_sources/data_source_imp.dart';
import 'package:socialapp/feature/story/data/repository.dart';
import 'package:socialapp/feature/story/domain/usecases.dart';
import 'package:socialapp/feature/story/presentation/bloc/story_bloc.dart';
import 'package:socialapp/feature/post/presentation/bloc/post_bloc.dart';
import 'package:socialapp/feature/post/data/repository.dart';
import 'package:socialapp/feature/post/domain/usecases.dart';

final GetIt locator = GetIt.instance;

void setupLocator() {
  // Registering the AuthRepository

  locator.registerLazySingleton<AuthRepository>(
      () => AuthrepositoryImp(RemoteAuthDatasource(FirebaseAuth.instance)));

  // Registering the use cases
  locator
      .registerLazySingleton<SendOTP>(() => SendOTP(locator<AuthRepository>()));
  locator.registerLazySingleton<VerifyOTP>(
      () => VerifyOTP(locator<AuthRepository>()));

  // Registering the AuthBloc
  locator.registerFactory<AuthBloc>(() => AuthBloc(
        sendOtpUseCase: locator<SendOTP>(),
        verifyOtpUseCase: locator<VerifyOTP>(),
      ));

  // Registering the StoryRepository

  locator.registerLazySingleton<StoryRepositoryImpl>(
      () => StoryRepositoryImpl(DataSourceImp(Dio())));

  //registering the story use case

  locator.registerLazySingleton<StoryUsecases>(
      () => StoryUsecases(locator<StoryRepositoryImpl>()));

  // registering the story bloc
  locator.registerFactory<StoryBloc>(() => StoryBloc(
        locator<StoryUsecases>(),
      ));

  // Registering the PostRepository
  locator.registerLazySingleton<PostRepositoryImpl>(
      () => PostRepositoryImpl(DataSourcesImpl(Dio())));

  //registering the post use case
  locator.registerLazySingleton<PostUsecases>(
      () => PostUsecases(locator<PostRepositoryImpl>()));

  // reistering the post bloc
  locator.registerFactory<PostBloc>(() => PostBloc(locator<PostUsecases>()));
}
