import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:socialapp/feature/Auth/persentation/bloc/auth_bloc.dart';
import 'package:socialapp/feature/Auth/persentation/screens/auth/interface.dart';
import 'package:socialapp/feature/post/presentation/bloc/post_bloc.dart';
import 'package:socialapp/feature/story/presentation/bloc/story_bloc.dart';
import 'package:socialapp/locator.dart';
import 'package:socialapp/firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  setupLocator();
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});
  @override
  Widget build(BuildContext context) {
     return MultiBlocProvider(
      providers:  [
         BlocProvider(
          create: (context) => locator<AuthBloc>(),
          ),
          BlocProvider(create: (context)=>locator<StoryBloc>(),),
          BlocProvider(create: (context)=>locator<PostBloc>(),)
      

  ],
       child:const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Interface(),
    )
      );
  }
}




