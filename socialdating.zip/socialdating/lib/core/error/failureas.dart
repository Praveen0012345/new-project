abstract class Failureas {
  final String failue;
  const Failureas(this.failue);
}

class ServerFailure extends Failureas {
  const ServerFailure(super.message);
}

class InputFailure extends Failureas {
  const InputFailure(super.message);
}
