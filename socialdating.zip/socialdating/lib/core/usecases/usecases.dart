abstract class Usecases<Type, params> {
  Future<Type>(params params);

  fetchPost(int i) {}

  getstory() {}
}
