import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:socialapp/feature/post/presentation/bloc/post_bloc.dart';
import 'package:socialapp/feature/post/presentation/screen/post_ui.dart';
import 'package:socialapp/feature/story/presentation/bloc/story_bloc.dart';
import 'package:socialapp/feature/story/presentation/story_ui.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    // Trigger fetching posts and stories
    context.read<PostBloc>().add(FetchPostEvent(id: 1));
    context.read<StoryBloc>().add(LoadStoriesEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MeetMe'),
        actions: [
          IconButton(icon: const Icon(Icons.add), onPressed: () {}),
          IconButton(icon: const Icon(Icons.message), onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Stories Section
            BlocBuilder<StoryBloc, StoryState>(
              builder: (context, state) {
                if (state is StoryLoadingState) {
                  return const Center(child: CircularProgressIndicator());
                } else if (state is StoryLoadedState) {
                  return Row(children: <Widget>[
                    Expanded(child: StoryList(stories: state.stories)),
                  ],);
                } else if (state is StoryErrorState) {
                  return const Center(child: Text('Failed to load stories.'));
                }
                return const SizedBox.shrink();
              },
            ),
            const SizedBox(height: 16),
            // Posts Section
            BlocBuilder<PostBloc, PostState>(
              builder: (context, state) {
                if (state is PostLoadingState) {
                  return const Center(child: CircularProgressIndicator());
                } else if (state is PostLoadedState) {
                  return Column(
                    children: state.posts.map((post) => PostUi(post: post, )).toList(),
                  );
                } else if (state is PostErrorState) {
                  return const Center(child: Text('Failed to load posts.'));
                }
                return const SizedBox.shrink();
              },
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
          BottomNavigationBarItem(icon: Icon(Icons.add), label: 'Add'),
          BottomNavigationBarItem(icon: Icon(Icons.message), label: 'Messages'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
