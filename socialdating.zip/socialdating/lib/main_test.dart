import 'package:flutter/material.dart';
import 'package:socialapp/feature/userProfile/presentation/widget/profile_tabs.dart';

void main() async {
  
  runApp(const MyTestApp());
}

class MyTestApp extends  StatelessWidget {
  const MyTestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const ProfileTabs(photos: [], videos: [], highlights: [],),
    );
  }
}