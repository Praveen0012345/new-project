class RelationshipEntity {
  final String id;
  final String user1Id;
  final String user1Name;
  final String user1ProfileUrl;
  final String user2Id;
  final String user2Name;
  final String user2ProfileUrl;
  final DateTime anniversaryDate;
  final String relationshipStatus;
  final List<String> photos;
  final String currentPhotoUrl;

  RelationshipEntity({
    required this.id,
    required this.user1Id,
    required this.user1Name,
    required this.user1ProfileUrl,
    required this.user2Id,
    required this.user2Name,
    required this.user2ProfileUrl,
    required this.anniversaryDate,
    required this.relationshipStatus,
    required this.photos,
    required this.currentPhotoUrl,
  });

  String get yearsTogetherText {
    final years = DateTime.now().difference(anniversaryDate).inDays ~/ 365;
    return 'TOGETHER SINCE $years YEARS';
  }
}
