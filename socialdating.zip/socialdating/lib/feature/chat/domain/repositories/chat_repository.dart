import '../entities/chat_entity.dart';

abstract class ChatRepository {
  Future<List<ChatRoomEntity>> getChatRooms();
  Future<List<ChatEntity>> getChatMessages(String chatRoomId);
  Future<void> sendMessage(ChatEntity message);
  Future<void> sendMediaMessage(ChatEntity message, String mediaPath);
  Future<void> markMessageAsRead(String messageId);
  Future<void> deleteMessage(String messageId);
  Stream<List<ChatEntity>> getChatMessagesStream(String chatRoomId);
  Stream<List<ChatRoomEntity>> getChatRoomsStream();
  Future<void> updateUserOnlineStatus(bool isOnline);
}
