class ChatEntity {
  final String id;
  final String senderId;
  final String receiverId;
  final String message;
  final String? mediaUrl;
  final String? mediaType; // 'audio', 'image', 'document'
  final DateTime timestamp;
  final bool isRead;
  final String? fileName; // For document messages
  final String? fileSize; // For document messages

  ChatEntity({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.message,
    this.mediaUrl,
    this.mediaType,
    required this.timestamp,
    required this.isRead,
    this.fileName,
    this.fileSize,
  });
}

class ChatRoomEntity {
  final String id;
  final String userId;
  final String username;
  final String userProfileUrl;
  final String lastMessage;
  final DateTime lastMessageTime;
  final bool isOnline;
  final bool hasUnreadMessages;
  final int unreadCount;

  ChatRoomEntity({
    required this.id,
    required this.userId,
    required this.username,
    required this.userProfileUrl,
    required this.lastMessage,
    required this.lastMessageTime,
    required this.isOnline,
    required this.hasUnreadMessages,
    required this.unreadCount,
  });
}
