import '../entities/chat_entity.dart';
import '../repositories/chat_repository.dart';

class ChatUseCases {
  final ChatRepository repository;

  ChatUseCases(this.repository);

  Future<List<ChatRoomEntity>> getChatRooms() {
    return repository.getChatRooms();
  }

  Future<List<ChatEntity>> getChatMessages(String chatRoomId) {
    return repository.getChatMessages(chatRoomId);
  }

  Future<void> sendMessage(ChatEntity message) {
    return repository.sendMessage(message);
  }

  Future<void> sendMediaMessage(ChatEntity message, String mediaPath) {
    return repository.sendMediaMessage(message, mediaPath);
  }

  Future<void> markMessageAsRead(String messageId) {
    return repository.markMessageAsRead(messageId);
  }

  Future<void> deleteMessage(String messageId) {
    return repository.deleteMessage(messageId);
  }

  Stream<List<ChatEntity>> getChatMessagesStream(String chatRoomId) {
    return repository.getChatMessagesStream(chatRoomId);
  }

  Stream<List<ChatRoomEntity>> getChatRoomsStream() {
    return repository.getChatRoomsStream();
  }

  Future<void> updateUserOnlineStatus(bool isOnline) {
    return repository.updateUserOnlineStatus(isOnline);
  }
}
