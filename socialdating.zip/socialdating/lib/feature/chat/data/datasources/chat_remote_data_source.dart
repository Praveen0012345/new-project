import '../models/chat_model.dart';

abstract class ChatRemoteDataSource {
  Future<List<ChatRoomModel>> getChatRooms();
  Future<List<ChatModel>> getChatMessages(String chatRoomId);
  Future<void> sendMessage(ChatModel message);
  Future<void> sendMediaMessage(ChatModel message, String mediaPath);
  Future<void> markMessageAsRead(String messageId);
  Future<void> deleteMessage(String messageId);
  Stream<List<ChatModel>> getChatMessagesStream(String chatRoomId);
  Stream<List<ChatRoomModel>> getChatRoomsStream();
  Future<void> updateUserOnlineStatus(bool isOnline);
  Future<String> uploadMedia(String mediaPath);
}
