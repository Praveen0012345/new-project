import 'dart:io';
import 'package:dio/dio.dart';
import '../models/chat_model.dart';
import 'chat_remote_data_source.dart';

class ChatRemoteDataSourceImpl implements ChatRemoteDataSource {
  final Dio dio;
  final String baseUrl;

  ChatRemoteDataSourceImpl({
    required this.dio,
    this.baseUrl = 'http://your-api-url/api',
  });

  @override
  Future<List<ChatRoomModel>> getChatRooms() async {
    try {
      final response = await dio.get('$baseUrl/chat/rooms');
      
      if (response.statusCode == 200) {
        final List<dynamic> data = response.data['chatRooms'];
        return data.map((json) => ChatRoomModel.fromJson(json)).toList();
      } else {
        throw Exception('Failed to get chat rooms');
      }
    } catch (e) {
      throw Exception('Failed to get chat rooms: $e');
    }
  }

  @override
  Future<List<ChatModel>> getChatMessages(String chatRoomId) async {
    try {
      final response = await dio.get('$baseUrl/chat/messages/$chatRoomId');
      
      if (response.statusCode == 200) {
        final List<dynamic> data = response.data['messages'];
        return data.map((json) => ChatModel.fromJson(json)).toList();
      } else {
        throw Exception('Failed to get chat messages');
      }
    } catch (e) {
      throw Exception('Failed to get chat messages: $e');
    }
  }

  @override
  Future<void> sendMessage(ChatModel message) async {
    try {
      final response = await dio.post(
        '$baseUrl/chat/messages',
        data: message.toJson(),
      );
      
      if (response.statusCode != 201) {
        throw Exception('Failed to send message');
      }
    } catch (e) {
      throw Exception('Failed to send message: $e');
    }
  }

  @override
  Future<void> sendMediaMessage(ChatModel message, String mediaPath) async {
    try {
      String mediaUrl = await uploadMedia(mediaPath);
      
      final messageWithMedia = ChatModel(
        id: message.id,
        senderId: message.senderId,
        receiverId: message.receiverId,
        message: message.message,
        mediaUrl: mediaUrl,
        mediaType: message.mediaType,
        timestamp: message.timestamp,
        isRead: message.isRead,
        fileName: message.fileName,
        fileSize: message.fileSize,
      );

      await sendMessage(messageWithMedia);
    } catch (e) {
      throw Exception('Failed to send media message: $e');
    }
  }

  @override
  Future<String> uploadMedia(String mediaPath) async {
    try {
      final file = File(mediaPath);
      final formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(file.path),
      });
      
      final response = await dio.post(
        '$baseUrl/chat/upload',
        data: formData,
      );
      
      if (response.statusCode == 200) {
        return response.data['url'];
      } else {
        throw Exception('Failed to upload media');
      }
    } catch (e) {
      throw Exception('Failed to upload media: $e');
    }
  }

  @override
  Future<void> markMessageAsRead(String messageId) async {
    try {
      final response = await dio.put('$baseUrl/chat/messages/$messageId/read');
      
      if (response.statusCode != 200) {
        throw Exception('Failed to mark message as read');
      }
    } catch (e) {
      throw Exception('Failed to mark message as read: $e');
    }
  }

  @override
  Future<void> deleteMessage(String messageId) async {
    try {
      final response = await dio.delete('$baseUrl/chat/messages/$messageId');
      
      if (response.statusCode != 200) {
        throw Exception('Failed to delete message');
      }
    } catch (e) {
      throw Exception('Failed to delete message: $e');
    }
  }

  @override
  Stream<List<ChatModel>> getChatMessagesStream(String chatRoomId) {
    // This should be implemented with WebSocket or Server-Sent Events
    throw UnimplementedError('Implement with WebSocket or SSE');
  }

  @override
  Stream<List<ChatRoomModel>> getChatRoomsStream() {
    // This should be implemented with WebSocket or Server-Sent Events
    throw UnimplementedError('Implement with WebSocket or SSE');
  }

  @override
  Future<void> updateUserOnlineStatus(bool isOnline) async {
    try {
      final response = await dio.put(
        '$baseUrl/chat/status',
        data: {'isOnline': isOnline},
      );
      
      if (response.statusCode != 200) {
        throw Exception('Failed to update online status');
      }
    } catch (e) {
      throw Exception('Failed to update online status: $e');
    }
  }
}
