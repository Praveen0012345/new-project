import '../../domain/entities/chat_entity.dart';
import '../../domain/repositories/chat_repository.dart';
import '../datasources/chat_remote_data_source.dart';
import '../models/chat_model.dart';

class ChatRepositoryImpl implements ChatRepository {
  final ChatRemoteDataSource remoteDataSource;

  ChatRepositoryImpl({required this.remoteDataSource});

  @override
  Future<List<ChatRoomEntity>> getChatRooms() async {
    try {
      final chatRooms = await remoteDataSource.getChatRooms();
      return chatRooms;
    } catch (e) {
      throw Exception('Failed to get chat rooms: $e');
    }
  }

  @override
  Future<List<ChatEntity>> getChatMessages(String chatRoomId) async {
    try {
      final messages = await remoteDataSource.getChatMessages(chatRoomId);
      return messages;
    } catch (e) {
      throw Exception('Failed to get chat messages: $e');
    }
  }

  @override
  Future<void> sendMessage(ChatEntity message) async {
    try {
      final chatModel = ChatModel(
        id: message.id,
        senderId: message.senderId,
        receiverId: message.receiverId,
        message: message.message,
        mediaUrl: message.mediaUrl,
        mediaType: message.mediaType,
        timestamp: message.timestamp,
        isRead: message.isRead,
        fileName: message.fileName,
        fileSize: message.fileSize,
      );
      await remoteDataSource.sendMessage(chatModel);
    } catch (e) {
      throw Exception('Failed to send message: $e');
    }
  }

  @override
  Future<void> sendMediaMessage(ChatEntity message, String mediaPath) async {
    try {
      final chatModel = ChatModel(
        id: message.id,
        senderId: message.senderId,
        receiverId: message.receiverId,
        message: message.message,
        mediaUrl: message.mediaUrl,
        mediaType: message.mediaType,
        timestamp: message.timestamp,
        isRead: message.isRead,
        fileName: message.fileName,
        fileSize: message.fileSize,
      );
      await remoteDataSource.sendMediaMessage(chatModel, mediaPath);
    } catch (e) {
      throw Exception('Failed to send media message: $e');
    }
  }

  @override
  Future<void> markMessageAsRead(String messageId) async {
    try {
      await remoteDataSource.markMessageAsRead(messageId);
    } catch (e) {
      throw Exception('Failed to mark message as read: $e');
    }
  }

  @override
  Future<void> deleteMessage(String messageId) async {
    try {
      await remoteDataSource.deleteMessage(messageId);
    } catch (e) {
      throw Exception('Failed to delete message: $e');
    }
  }

  @override
  Stream<List<ChatEntity>> getChatMessagesStream(String chatRoomId) {
    return remoteDataSource.getChatMessagesStream(chatRoomId);
  }

  @override
  Stream<List<ChatRoomEntity>> getChatRoomsStream() {
    return remoteDataSource.getChatRoomsStream();
  }

  @override
  Future<void> updateUserOnlineStatus(bool isOnline) async {
    try {
      await remoteDataSource.updateUserOnlineStatus(isOnline);
    } catch (e) {
      throw Exception('Failed to update online status: $e');
    }
  }
}
