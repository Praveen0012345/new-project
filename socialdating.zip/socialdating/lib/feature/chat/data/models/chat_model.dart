// lib/feature/chat/data/models/chat_model.dart

import 'package:socialapp/feature/chat/domain/entities/chat_entity.dart';

class ChatModel extends ChatEntity {
  ChatModel({
    required String id,
    required String senderId,
    required String receiverId,
    required String message,
    String? mediaUrl,
    String? mediaType,
    required DateTime timestamp,
    required bool isRead,
    String? fileName,
    String? fileSize,
  }) : super(
          id: id,
          senderId: senderId,
          receiverId: receiverId,
          message: message,
          mediaUrl: mediaUrl,
          mediaType: mediaType,
          timestamp: timestamp,
          isRead: isRead,
          fileName: fileName,
          fileSize: fileSize,
        );

  // From JSON to Model (ChatModel)
  factory ChatModel.fromJson(Map<String, dynamic> json) {
    return ChatModel(
      id: json['id'] as String,
      senderId: json['senderId'] as String,
      receiverId: json['receiverId'] as String,
      message: json['message'] as String,
      mediaUrl: json['mediaUrl'] as String?,
      mediaType: json['mediaType'] as String?,
      timestamp: DateTime.parse(json['timestamp'] as String),
      isRead: json['isRead'] as bool,
      fileName: json['fileName'] as String?,
      fileSize: json['fileSize'] as String?,
    );
  }

  // Model to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'senderId': senderId,
      'receiverId': receiverId,
      'message': message,
      'mediaUrl': mediaUrl,
      'mediaType': mediaType,
      'timestamp': timestamp.toIso8601String(),
      'isRead': isRead,
      'fileName': fileName,
      'fileSize': fileSize,
    };
  }
}



class ChatRoomModel extends ChatRoomEntity {
  ChatRoomModel({
    required String id,
    required String userId,
    required String username,
    required String userProfileUrl,
    required String lastMessage,
    required DateTime lastMessageTime,
    required bool isOnline,
    required bool hasUnreadMessages,
    required int unreadCount,
  }) : super(
          id: id,
          userId: userId,
          username: username,
          userProfileUrl: userProfileUrl,
          lastMessage: lastMessage,
          lastMessageTime: lastMessageTime,
          isOnline: isOnline,
          hasUnreadMessages: hasUnreadMessages,
          unreadCount: unreadCount,
        );

  // From JSON to Model (ChatRoomModel)
  factory ChatRoomModel.fromJson(Map<String, dynamic> json) {
    return ChatRoomModel(
      id: json['id'] as String,
      userId: json['userId'] as String,
      username: json['username'] as String,
      userProfileUrl: json['userProfileUrl'] as String,
      lastMessage: json['lastMessage'] as String,
      lastMessageTime: DateTime.parse(json['lastMessageTime'] as String),
      isOnline: json['isOnline'] as bool,
      hasUnreadMessages: json['hasUnreadMessages'] as bool,
      unreadCount: json['unreadCount'] as int,
    );
  }

  // Model to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'username': username,
      'userProfileUrl': userProfileUrl,
      'lastMessage': lastMessage,
      'lastMessageTime': lastMessageTime.toIso8601String(),
      'isOnline': isOnline,
      'hasUnreadMessages': hasUnreadMessages,
      'unreadCount': unreadCount,
    };
  }
}
