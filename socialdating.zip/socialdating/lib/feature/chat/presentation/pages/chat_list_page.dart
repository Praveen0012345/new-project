import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:socialapp/feature/chat/domain/entities/chat_entity.dart';
import '../bloc/chat_bloc.dart';
import '../bloc/chat_state.dart';
import '../widgets/chat_room_item.dart';
import 'chat_room_page.dart';

class ChatListPage extends StatefulWidget {
  const ChatListPage({super.key});

  @override
  State<ChatListPage> createState() => _ChatListPageState();
}

class _ChatListPageState extends State<ChatListPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _selectedIndex = _tabController.index;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            const Text(
              '_23divya00',
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Spacer(),
            IconButton(
              icon: const Icon(Icons.search, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: const Icon(Icons.more_vert, color: Colors.black),
              onPressed: () {},
            ),
          ],
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.grey[200],
              borderRadius: BorderRadius.circular(8),
            ),
            child: TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                color: const Color(0xFF6B8E92),
                borderRadius: BorderRadius.circular(8),
              ),
              labelColor: Colors.white,
              unselectedLabelColor: Colors.black,
              tabs: const [
                Tab(text: 'All Chats'),
                Tab(text: 'Active'),
                Tab(text: 'Requests'),
              ],
            ),
          ),
        ),
      ),
      body: BlocBuilder<ChatBloc, ChatState>(
        builder: (context, state) {
          if (state is ChatRoomsLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is ChatRoomsLoaded) {
            return TabBarView(
              controller: _tabController,
              children: [
                _buildChatList(state.chatRooms),
                _buildActiveList(state.chatRooms.where((room) => room.isOnline).toList()),
                _buildRequestsList([]), // Add chat requests when available
              ],
            );
          } else if (state is ChatError) {
            return Center(
              child: Text(
                'Error: ${state.message}',
                style: const TextStyle(color: Colors.red),
              ),
            );
          }
          return const SizedBox();
        },
      ),
    );
  }

  Widget _buildChatList(List<ChatRoomEntity> chatRooms) {
    return ListView.builder(
      itemCount: chatRooms.length,
      itemBuilder: (context, index) {
        final chatRoom = chatRooms[index];
        return ChatRoomItem(
          chatRoom: chatRoom,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ChatRoomPage(chatRoom: chatRoom),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildActiveList(List<ChatRoomEntity> activeRooms) {
    return ListView.builder(
      itemCount: activeRooms.length,
      itemBuilder: (context, index) {
        final chatRoom = activeRooms[index];
        return ChatRoomItem(
          chatRoom: chatRoom,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ChatRoomPage(chatRoom: chatRoom),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildRequestsList(List<ChatRoomEntity> requests) {
    if (requests.isEmpty) {
      return const Center(
        child: Text(
          'No message requests',
          style: TextStyle(
            color: Colors.grey,
            fontSize: 16,
          ),
        ),
      );
    }
    return ListView.builder(
      itemCount: requests.length,
      itemBuilder: (context, index) {
        final request = requests[index];
        return ChatRoomItem(
          chatRoom: request,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ChatRoomPage(chatRoom: request),
              ),
            );
          },
        );
      },
    );
  }
}


// o navigate to this page from the homepage, update the message icon's onPressed handler in home_page.dart
// IconButton(
//   icon: const Icon(Icons.chat_bubble_outline),
//   onPressed: () {
//     Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (context) => BlocProvider(
//           create: (context) => ChatBloc(
//             chatUseCases: ChatUseCases(
//               ChatRepositoryImpl(
//                 remoteDataSource: ChatRemoteDataSourceImpl(
//                   dio: Dio(),
//                   baseUrl: 'your-api-url',
//                 ),
//               ),
//             ),
//           )..add(LoadChatRooms()),
//           child: const ChatListPage(),
//         ),
//       ),
//     );
//   },
// ),