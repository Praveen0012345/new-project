import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../domain/entities/chat_entity.dart';
import '../bloc/chat_bloc.dart';
import '../bloc/chat_event.dart';
import '../bloc/chat_state.dart';
import '../widgets/chat_message_item.dart';
import '../widgets/chat_input.dart';

class ChatRoomPage extends StatelessWidget {
  final ChatRoomEntity chatRoom;

  const ChatRoomPage({super.key, required this.chatRoom});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 30,
        title: Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundImage: NetworkImage(chatRoom.userProfileUrl),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  chatRoom.username,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (chatRoom.isOnline)
                  const Text(
                    'Online',
                    style: TextStyle(fontSize: 12, color: Colors.green),
                  ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.video_call),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.call),
            onPressed: () {},
          ),
        ],
      ),
      body: BlocBuilder<ChatBloc, ChatState>(
        builder: (context, state) {
          if (state is ChatMessagesLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is ChatMessagesLoaded) {
            return Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    reverse: true,
                    padding: const EdgeInsets.all(16),
                    itemCount: state.messages.length,
                    itemBuilder: (context, index) {
                      final message = state.messages[index];
                      return ChatMessageItem(
                        message: message,
                        isMe: message.senderId == 'current_user_id', // Replace with actual user ID
                      );
                    },
                  ),
                ),
                ChatInput(
                  onSendMessage: (message) {
                    final newMessage = ChatEntity(
                      id: DateTime.now().toString(),
                      senderId: 'current_user_id', // Replace with actual user ID
                      receiverId: chatRoom.userId,
                      message: message,
                      timestamp: DateTime.now(),
                      isRead: false,
                    );
                    context.read<ChatBloc>().add(SendMessage(newMessage));
                  },
                  onAttachFile: () {
                    // Handle file attachment
                  },
                ),
              ],
            );
          } else if (state is ChatError) {
            return Center(
              child: Text(
                'Error: ${state.message}',
                style: const TextStyle(color: Colors.red),
              ),
            );
          }
          return const SizedBox();
        },
      ),
    );
  }
}
