import '../../domain/entities/chat_entity.dart';

abstract class ChatEvent {}

class LoadChatRooms extends ChatEvent {}

class UpdateChatRooms extends ChatEvent {
  final List<ChatRoomEntity> chatRooms;

  UpdateChatRooms(this.chatRooms);
}

class LoadChatMessages extends ChatEvent {
  final String chatRoomId;

  LoadChatMessages(this.chatRoomId);
}

class UpdateChatMessages extends ChatEvent {
  final List<ChatEntity> messages;

  UpdateChatMessages(this.messages);
}

class SendMessage extends ChatEvent {
  final ChatEntity message;

  SendMessage(this.message);
}

class SendMediaMessage extends ChatEvent {
  final ChatEntity message;
  final String mediaPath;

  SendMediaMessage(this.message, this.mediaPath);
}

class MarkMessageAsRead extends ChatEvent {
  final String messageId;

  MarkMessageAsRead(this.messageId);
}

class DeleteMessage extends ChatEvent {
  final String messageId;

  DeleteMessage(this.messageId);
}

class UpdateOnlineStatus extends ChatEvent {
  final bool isOnline;

  UpdateOnlineStatus(this.isOnline);
}
