import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../domain/usecases/chat_usecases.dart';
import 'chat_event.dart';
import 'chat_state.dart';

class ChatBloc extends Bloc<ChatEvent, ChatState> {
  final ChatUseCases chatUseCases;
  StreamSubscription? _chatRoomsSubscription;
  StreamSubscription? _messagesSubscription;

  ChatBloc({required this.chatUseCases}) : super(ChatInitial()) {
    on<LoadChatRooms>((event, emit) async {
      try {
        emit(ChatRoomsLoading());
        final chatRooms = await chatUseCases.getChatRooms();
        emit(ChatRoomsLoaded(chatRooms));
        
        // Subscribe to real-time updates
        _chatRoomsSubscription?.cancel();
        _chatRoomsSubscription = chatUseCases.getChatRoomsStream().listen(
          (chatRooms) {
            add(UpdateChatRooms(chatRooms));
          },
        );
      } catch (e) {
        emit(ChatError(e.toString()));
      }
    });

    on<UpdateChatRooms>((event, emit) {
      emit(ChatRoomsLoaded(event.chatRooms));
    });

    on<LoadChatMessages>((event, emit) async {
      try {
        emit(ChatMessagesLoading());
        final messages = await chatUseCases.getChatMessages(event.chatRoomId);
        emit(ChatMessagesLoaded(messages));

        // Subscribe to real-time updates
        _messagesSubscription?.cancel();
        _messagesSubscription = chatUseCases.getChatMessagesStream(event.chatRoomId).listen(
          (messages) {
            add(UpdateChatMessages(messages));
          },
        );
      } catch (e) {
        emit(ChatError(e.toString()));
      }
    });

    on<UpdateChatMessages>((event, emit) {
      if (state is ChatMessagesLoaded) {
        emit(ChatMessagesLoaded(event.messages));
      }
    });

    on<SendMessage>((event, emit) async {
      try {
        await chatUseCases.sendMessage(event.message);
      } catch (e) {
        emit(ChatError(e.toString()));
      }
    });

    on<SendMediaMessage>((event, emit) async {
      try {
        await chatUseCases.sendMediaMessage(event.message, event.mediaPath);
      } catch (e) {
        emit(ChatError(e.toString()));
      }
    });

    on<MarkMessageAsRead>((event, emit) async {
      try {
        await chatUseCases.markMessageAsRead(event.messageId);
      } catch (e) {
        emit(ChatError(e.toString()));
      }
    });

    on<DeleteMessage>((event, emit) async {
      try {
        await chatUseCases.deleteMessage(event.messageId);
      } catch (e) {
        emit(ChatError(e.toString()));
      }
    });

    on<UpdateOnlineStatus>((event, emit) async {
      try {
        await chatUseCases.updateUserOnlineStatus(event.isOnline);
      } catch (e) {
        emit(ChatError(e.toString()));
      }
    });
  }

  @override
  Future<void> close() {
    _chatRoomsSubscription?.cancel();
    _messagesSubscription?.cancel();
    return super.close();
  }
}
