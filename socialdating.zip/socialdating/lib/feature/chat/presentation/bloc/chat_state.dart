import '../../domain/entities/chat_entity.dart';

abstract class ChatState {}

class ChatInitial extends ChatState {}

class ChatRoomsLoading extends ChatState {}

class ChatRoomsLoaded extends ChatState {
  final List<ChatRoomEntity> chatRooms;

  ChatRoomsLoaded(this.chatRooms);
}

class ChatMessagesLoading extends ChatState {}

class ChatMessagesLoaded extends ChatState {
  final List<ChatEntity> messages;

  ChatMessagesLoaded(this.messages);
}

class ChatError extends ChatState {
  final String message;

  ChatError(this.message);
}
