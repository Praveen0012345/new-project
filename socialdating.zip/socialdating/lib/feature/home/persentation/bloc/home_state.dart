part of 'home_bloc.dart';

sealed class HomeState extends Equatable {
  const HomeState();

  @override
  List<Object> get props => [];
}

class HomeInitial extends HomeState {}

class HomeLoading extends HomeState {}

class Homeloaded extends HomeState {
  final List<Story> stories;
  final List<Post> posts;
  final String currentUserId;
 

  const Homeloaded(
      {required this.stories,
      required this.posts,
      required this.currentUserId,
     });
}
class HomeErrorState extends HomeState {
  final String message;

  const HomeErrorState({required this.message});
}