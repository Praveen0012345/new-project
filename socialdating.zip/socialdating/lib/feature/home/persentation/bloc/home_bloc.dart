import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:socialapp/feature/post/domain/entities/entites.dart';

import 'package:socialapp/feature/post/domain/usecases.dart';
import 'package:socialapp/feature/story/domain/entites.dart';

import 'package:socialapp/feature/story/domain/usecases.dart';

part 'home_event.dart';
part 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final StoryUsecases storyUsecases;
  final PostUsecases postUsecases;

  HomeBloc(
      this.storyUsecases,
      this.postUsecases,
      EventHandler<HomeLoading, HomeState> _homeLoading,
      EventHandler<Homeloaded, HomeState> _homeStoryFetched)
      : super(HomeInitial()) {
    on<HomeInitialEvent>(
        _onHomeLoaded as EventHandler<HomeInitialEvent, HomeState> );
  }

  FutureOr<void> _onHomeLoaded(
      Homeloaded event, Emitter<HomeState> emit) async {
    try {
      emit(HomeLoading());
      final stories = await storyUsecases
          .getstory(Fetchstoryparams(userId: event.currentUserId));
      final posts = await postUsecases
          .fetchPost(Fetchpostparams(id: event.currentUserId));
      emit(Homeloaded(
          stories: stories,
          posts: posts,
          currentUserId: event.currentUserId,
          ));
    } catch (e) {
      emit(HomeErrorState(message: e.toString()));
    }
  }
}
