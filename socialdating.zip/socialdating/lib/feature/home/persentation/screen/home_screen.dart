import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:socialapp/feature/home/persentation/bloc/home_bloc.dart';
import 'package:socialapp/feature/post/presentation/widgets/post_list.dart';
import 'package:socialapp/feature/relationship/presentation/pages/relationship_page.dart';
import 'package:socialapp/feature/story/domain/entites.dart';
import 'package:socialapp/feature/story/presentation/story_ui.dart';
import 'package:socialapp/feature/userProfile/presentation/bloc/profile_bloc.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: BlocBuilder(builder: (context, state) {
        if (state is HomeLoading) {
          return const Center(child: CircularProgressIndicator());
        } else if (state is Homeloaded) {
          RefreshIndicator(
            onRefresh: () async{
              context.read<HomeBloc>().add(HomeInitialEvent());
            },
            child: CustomScrollView(
              slivers:[
                 SliverToBoxAdapter(
                    child: StoryList(stories: state.stories),
                  ),
                  SliverToBoxAdapter(
                    child: const Divider(height: 1),
                  ),
                  SliverToBoxAdapter(
                    child: PostList(posts: state.posts),
                  ),
              ]
            ),
          );
          
        }else if (state is HomeErrorState){
          return Center(
              child: Text(
                'Error: ${state.message}',
                style: const TextStyle(color: Colors.red),
              ),
            );
        }return const SizedBox();
      }),

      bottomNavigationBar: Container(
        decoration:  BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 1,
              blurRadius: 10,
              offset:const  Offset(0, -1),
            ),
          ]
        ),
        child: SafeArea(
          child: SizedBox(
            height: 60,
            child: Stack(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildNavItem(0, Icons.home_outlined, Icons.home),
                    _buildNavItem(1, Icons.search_outlined, Icons.search),
                    const SizedBox(width: 60), // Space for center button
                    _buildNavItem(3, Icons.notifications_outlined, Icons.notifications),
                    _buildProfileAvatar(),
                  ],
                ),
                Positioned.fill(
                  child: Align(
                    alignment: Alignment.center,
                    child: Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Theme.of(context).primaryColor.withOpacity(0.8),
                            Theme.of(context).primaryColor,
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Theme.of(context).primaryColor.withOpacity(0.3),
                            spreadRadius: 1,
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: IconButton(
                        icon: const Icon(Icons.favorite, color: Colors.white),
                        onPressed: () {
                          Navigator.of(context).push(
                            PageRouteBuilder(
                              pageBuilder: (context, animation, secondaryAnimation) {
                                return const RelationshipPage();
                              },
                              transitionsBuilder: (context, animation, secondaryAnimation, child) {
                                return FadeTransition(
                                  opacity: animation,
                                  child: child,
                                );
                              },
                              transitionDuration: const Duration(milliseconds: 500),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  Widget _buildNavItem(int index, IconData outlinedIcon, IconData filledIcon) {
    final isSelected = _selectedIndex == index;
    return InkWell(
      onTap: () => _onItemTapped(index),
      child: SizedBox(
        width: 60,
        height: 60,
        child: Icon(
          isSelected ? filledIcon : outlinedIcon,
          color: isSelected ? Theme.of(context).primaryColor : Colors.black54,
          size: 28,
        ),
      ),
    );
  }

  Widget _buildProfileAvatar() {
    return BlocBuilder<ProfileBloc, ProfileState>(
      builder: (context, state) {
        String profileUrl = '';
        if (state is ProfileLoaded) {
          profileUrl = state.profile.profileUrl;
        }
        return InkWell(
          onTap: () => _onItemTapped(4),
          child: Container(
            width: 60,
            height: 60,
            padding: const EdgeInsets.all(15),
            child: CircleAvatar(
              backgroundImage: profileUrl.isNotEmpty
                  ? NetworkImage(profileUrl)
                  : const AssetImage('assets/images/default_avatar.png')
                      as ImageProvider,
            ),
          ),
        );
      },
    );
  }
}




