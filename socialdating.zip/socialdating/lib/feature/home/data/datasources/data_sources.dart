import 'package:socialapp/feature/story/data/models.dart';

abstract class HomeDataSources{
  Future<void> createStory(StoryModel story, String mediaPath);
  Future<void> likePost(String postId);
  Future<void> unlikePost(String postId);
  Future<void> savePost(String postId);
  Future<void> unsavePost(String postId);
  Future<void> addComment(String postId, String comment);
  Future<void> deleteComment(String postId, String commentId);
  Future<void> sharePost(String postId);
  Future<String> uploadMedia(String mediaPath);
}