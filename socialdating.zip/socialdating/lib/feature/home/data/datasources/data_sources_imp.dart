import 'package:socialapp/feature/home/data/datasources/data_sources.dart';
import 'package:socialapp/feature/story/data/models.dart';

class DataSourcesImp extends HomeDataSources{
  @override
  Future<void> addComment(String postId, String comment) {
    // TODO: implement addComment
    throw UnimplementedError();
  }

  @override
  Future<void> createStory(StoryModel story, String mediaPath) {
    // TODO: implement createStory
    throw UnimplementedError();
  }

  @override
  Future<void> deleteComment(String postId, String commentId) {
    // TODO: implement deleteComment
    throw UnimplementedError();
  }

  @override
  Future<void> likePost(String postId) {
    // TODO: implement likePost
    throw UnimplementedError();
  }

  @override
  Future<void> savePost(String postId) {
    // TODO: implement savePost
    throw UnimplementedError();
  }

  @override
  Future<void> sharePost(String postId) {
    // TODO: implement sharePost
    throw UnimplementedError();
  }

  @override
  Future<void> unlikePost(String postId) {
    // TODO: implement unlikePost
    throw UnimplementedError();
  }

  @override
  Future<void> unsavePost(String postId) {
    // TODO: implement unsavePost
    throw UnimplementedError();
  }

  @override
  Future<String> uploadMedia(String mediaPath) {
    // TODO: implement uploadMedia
    throw UnimplementedError();
  }
}