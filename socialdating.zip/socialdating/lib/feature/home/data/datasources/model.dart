import 'package:socialapp/feature/home/domain/entity.dart';
import 'package:socialapp/feature/post/data/models/models.dart';
import 'package:socialapp/feature/post/domain/entities/entites.dart';
import 'package:socialapp/feature/story/data/models.dart';

class HomeModel extends HomeEntity {
  HomeModel(
      {required super.stories,
      required final List<Post> post,
      required,
      required super.currentUserId})
      : super(posts: post);

//json to model 
factory HomeModel.fromJson(Map<String, dynamic> json) {
    return HomeModel(
      stories: (json['stories'] as List)
          .map((story) => StoryModel.fromJson(story))
          .toList(),
      post: (json['posts'] as List)
          .map((post) => PostModel.fromJson(post))
          .toList(),
      currentUserId: json['currentUserId'] as String,
    );
  }

 //model to json 
 Map<String, dynamic> toJson() {
    return {
      'stories': stories.map((story) => (story as StoryModel).toJson()).toList(),
      'posts': posts.map((post) => (post as PostModel).toJson()).toList(),
      'currentUserId': currentUserId,
    };
  } 

}