// import 'package:socialapp/feature/story/domain/entites.dart';

// abstract class HomeRepositoryDomain{
//   Future<void> createStory(Story story, String mediaPath);
// }