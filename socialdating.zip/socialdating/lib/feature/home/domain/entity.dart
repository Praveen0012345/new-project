import 'package:socialapp/feature/post/domain/entities/entites.dart';
import 'package:socialapp/feature/story/domain/entites.dart';

class HomeEntity {
  final List<Story> stories;
  final List<Post> posts;
  final String currentUserId;

  HomeEntity({
    required this.stories,
    required this.posts,
    required this.currentUserId,
  });
}