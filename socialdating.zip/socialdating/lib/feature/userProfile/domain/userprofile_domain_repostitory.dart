import 'package:socialapp/feature/userProfile/domain/entites.dart';

abstract class UserprofileDomainRepostitory {

  Future<ProfileEntity> getProfile(String userId);
  Future<void> updateProfile(ProfileEntity profile);
  Future<void> followUser(String userId);
  Future<void> unfollowUser(String userId);
  Future<List<String>> getPhotos(String userId);
  Future<List<String>> getVideos(String userId);
  Future<List<String>> getHighlights(String userId);
}

