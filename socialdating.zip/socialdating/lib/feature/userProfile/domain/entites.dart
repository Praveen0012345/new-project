class ProfileEntity {
  final String id;
  final String username;
  final String fullName;
  final String bio;
  final String profileImageUrl;
  final String coverImageUrl;
  final int postsCount;
  final int followersCount;
  final int followingCount;
  final List<String> photos;
  final List<String> videos;
  final List<String> highlights;
  final bool isCurrentUser;

  ProfileEntity({
    required this.id,
    required this.username,
    required this.fullName,
    required this.bio,
    required this.profileImageUrl,
    required this.coverImageUrl,
    required this.postsCount,
    required this.followersCount,
    required this.followingCount,
    required this.photos,
    required this.videos,
    required this.highlights,
    this.isCurrentUser = false,
  });
}
