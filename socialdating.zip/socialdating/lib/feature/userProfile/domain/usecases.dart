import 'package:socialapp/feature/userProfile/domain/entites.dart';
import 'package:socialapp/feature/userProfile/domain/userprofile_domain_repostitory.dart';

class UserProfileUsecases {
  final UserprofileDomainRepostitory userprofileDomainRepostitory;
  UserProfileUsecases({required this.userprofileDomainRepostitory});

  Future<void> updateprofile(ProfileEntity profileEntity) async{
    return userprofileDomainRepostitory.updateProfile(profileEntity);
  }

  Future<ProfileEntity> getprofile(String userId) async{
  return await userprofileDomainRepostitory.getProfile(userId);
  }

  Future<void> followuser(String userId)async{    
    return userprofileDomainRepostitory.followUser(userId);
  }
  Future<void> unfollowuser( String userId)async{
    return await userprofileDomainRepostitory.unfollowUser(userId);
  }
   Future<List<String>> gethighlights(String userId)async{
      return await userprofileDomainRepostitory.getHighlights(userId);
  }

  Future<List<String>> getphotos(String userId)async{
     return await userprofileDomainRepostitory.getPhotos(userId);
  }
  Future<List<String>> getvideos(String userId)async{
     return await userprofileDomainRepostitory.getVideos(userId);
  }

}


class Failure{
  final String message;
  const Failure({required this.message});
}