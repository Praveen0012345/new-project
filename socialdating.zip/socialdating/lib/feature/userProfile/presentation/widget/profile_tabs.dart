import 'package:flutter/material.dart';

class ProfileTabs extends StatelessWidget {
  final List<String> photos;
  final List<String> videos;
  final List<String> highlights;

  const ProfileTabs({
    super.key,
    required this.photos,
    required this.videos,
    required this.highlights,
  });

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: DefaultTabController(
        length: 3,
        child: Column(
          children: [
            const TabBar(
              tabs: [
                Tab(icon: Icon(Icons.grid_on)),
                Tab(icon: Icon(Icons.play_circle_outline)),
                Tab(text: 'Highlights'),
              ],
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height,
              child: TabBarView(
                children: [
                  _buildGridView(photos),
                  _buildGridView(videos),
                  _buildGridView(highlights),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGridView(List<String> items) {
    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 2,
        mainAxisSpacing: 2,
      ),
      itemCount: items.length,
      itemBuilder: (context, index) {
        return Image.network(
          items[index],
          fit: BoxFit.cover,
        );
      },
    );
  }
}
