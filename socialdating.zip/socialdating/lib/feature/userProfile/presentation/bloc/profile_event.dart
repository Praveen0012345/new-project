part of 'profile_bloc.dart';

sealed class ProfileEvent extends Equatable {
  const ProfileEvent();

  @override
  List<Object> get props => [];
}
class LoadProfile extends ProfileEvent {
  final String userId;

  const LoadProfile({required this.userId});
}
class UpdateProfile extends ProfileEvent {
  final ProfileEntity profile;

  const UpdateProfile({required this.profile});
}

class FollowUser extends ProfileEvent {
  final String userId;

  const FollowUser({required this.userId});
}

class UnfollowUser extends ProfileEvent {
  final String userId;

  const UnfollowUser({required this.userId});
}