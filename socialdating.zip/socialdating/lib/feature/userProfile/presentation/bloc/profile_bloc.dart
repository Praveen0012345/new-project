import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:socialapp/feature/userProfile/domain/entites.dart';
import 'package:socialapp/feature/userProfile/domain/usecases.dart';

part 'profile_event.dart';
part 'profile_state.dart';

class ProfileBloc extends Bloc<ProfileEvent, ProfileState> {
  final UserProfileUsecases userProfileUsecases;
  ProfileBloc({required this.userProfileUsecases}) : super(ProfileInitial()) {
    on<LoadProfile>((event, emit) async{
     try {
        emit(ProfileLoading());
        final profile = await userProfileUsecases.getprofile(event.userId);
        final photos = await userProfileUsecases.getphotos(event.userId);
        final videos = await userProfileUsecases.getvideos(event.userId);
        final highlights = await userProfileUsecases.gethighlights(event.userId);
        emit(ProfileLoaded(
          profile: profile,
          photos: photos,
          videos: videos,
          highlights: highlights,
        ));
      } catch (e) {
        emit(ProfileError(message: e.toString()));
      }
    });

     on<FollowUser>((event, emit) async {
      try {
        await userProfileUsecases.followuser(event.userId);
        add(LoadProfile(userId: event.userId));
      } catch (e) {
        emit(ProfileError(message: e.toString()));
      }
    });

     on<UnfollowUser>((event, emit) async {
      try {
        await userProfileUsecases.unfollowuser(event.userId);
        add(LoadProfile(userId: event.userId));
      } catch (e) {
        emit(ProfileError(message: e.toString()));
      }
    });
  }
}
