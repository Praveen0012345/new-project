part of 'profile_bloc.dart';

sealed class ProfileState extends Equatable {
  const ProfileState();
  
  @override
  List<Object> get props => [];
}

final class ProfileInitial extends ProfileState {}
class ProfileLoading extends ProfileState {}
class ProfileLoaded extends ProfileState {
  final ProfileEntity profile;
  final List<String> photos;
  final List<String> videos;
  final List<String> highlights;

  const ProfileLoaded({
    required this.profile,
    required this.photos,
    required this.videos,
    required this.highlights,
  });
}
class ProfileUpdating extends ProfileState {}
class ProfileError extends ProfileState {
  final String message;

  const ProfileError({required this.message});
}