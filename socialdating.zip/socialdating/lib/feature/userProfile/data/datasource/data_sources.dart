import 'package:socialapp/feature/userProfile/data/models.dart';


abstract class DataSources {
  Future<ProfileModel> getProfile(String userId);
  Future<void> updateProfile(ProfileModel profilemodel);
  Future<void> followUser(String userId);
  Future<void> unfollowUser(String userId);
  Future<List<String>> getPhotos(String userId);
  Future<List<String>> getVideos(String userId);
  Future<List<String>> getHighlits(String userId);
}
