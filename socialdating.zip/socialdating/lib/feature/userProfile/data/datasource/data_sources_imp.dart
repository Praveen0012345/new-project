import 'package:dio/dio.dart';
import 'package:socialapp/feature/userProfile/data/datasource/data_sources.dart';
import 'package:socialapp/feature/userProfile/data/models.dart';

class DataSourcesImp extends DataSources {
  final Dio dio;
  DataSourcesImp({required this.dio});
  @override
  Future<void> followUser(String userId) async {
    await dio.post('/users/$userId/follow'); //link of backend 
  }

  @override
  Future<List<String>> getHighlits(String userId)async {
  final response = await dio.get('/users/$userId/highlights');
    return response.data.map((highlight) => highlight['url']).toList();
  }

  @override
  Future<List<String>> getPhotos(String userId) async{
     final response = await dio.get('/users/$userId/photos');
    return response.data.map((photo) => photo['url']).toList();
  }

  @override
  Future<ProfileModel> getProfile(String userId) async{
     final response = await dio.get('/users/$userId/profile');  //link of backend 
    return ProfileModel.fromJson(response.data);
  }

  @override
  Future<List<String>> getVideos(String userId) async{
    final response = await dio.get('/users/$userId/videos');
    return response.data.map((video) => video['url']).toList();
  }

  @override
  Future<void> unfollowUser(String userId) async{
     await dio.delete('/users/$userId/follow');
  }

  @override
  Future<void> updateProfile(ProfileModel profilemodel) async{
    await dio.put('/users/${profilemodel.id}/profile', data: profilemodel.toJson());
  }
}
