import 'package:socialapp/feature/userProfile/data/datasource/data_sources_imp.dart';
import 'package:socialapp/feature/userProfile/data/models.dart';
import 'package:socialapp/feature/userProfile/domain/entites.dart';
import 'package:socialapp/feature/userProfile/domain/userprofile_domain_repostitory.dart';

class UserprofileDataRepository implements UserprofileDomainRepostitory {
  final DataSourcesImp dataSourcesImp;
  UserprofileDataRepository({required this.dataSourcesImp});
  @override
  Future<void> followUser(String userId) async {
    return await dataSourcesImp.followUser(userId);
  }

  @override
  Future<List<String>> getHighlights(String userId) async {
    return await dataSourcesImp.getHighlits(userId);
  }

  @override
  Future<List<String>> getPhotos(String userId) async {
    return await dataSourcesImp.getPhotos(userId);
  }

  @override
  Future<ProfileEntity> getProfile(String userId) async {
    return await dataSourcesImp.getProfile(userId);
  }

  @override
  Future<List<String>> getVideos(String userId) async {
    return await dataSourcesImp.getVideos(userId);
  }

  @override
  Future<void> unfollowUser(String userId) async {
    return await dataSourcesImp.unfollowUser(userId);
  }

  @override
  Future<void> updateProfile(ProfileEntity profile) async {
    return await dataSourcesImp.updateProfile(ProfileModel(
        id: profile.id,
        username: profile.username,
        fullName: profile.fullName,
        bio: profile.bio,
        profileImageUrl: profile.profileImageUrl,
        coverImageUrl: profile.coverImageUrl,
        postsCount: profile.postsCount,
        followersCount: profile.followersCount,
        followingCount: profile.followingCount,
        photos: profile.photos,
        videos: profile.videos,
        highlights: profile.highlights,
        ));
  }
}
