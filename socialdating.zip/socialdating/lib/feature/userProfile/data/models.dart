// lib/feature/userProfile/data/models/profile_model.dart
import 'package:socialapp/feature/userProfile/domain/entites.dart';


class ProfileModel extends ProfileEntity {
  ProfileModel({
    required String id,
    required String username,
    required String fullName,
    required String bio,
    required String profileImageUrl,
    required String coverImageUrl,
    required int postsCount,
    required int followersCount,
    required int followingCount,
    required List<String> photos,
    required List<String> videos,
    required List<String> highlights,
    bool isCurrentUser = false,
  }) : super(
          id: id,
          username: username,
          fullName: fullName,
          bio: bio,
          profileImageUrl: profileImageUrl,
          coverImageUrl: coverImageUrl,
          postsCount: postsCount,
          followersCount: followersCount,
          followingCount: followingCount,
          photos: photos,
          videos: videos,
          highlights: highlights,
          isCurrentUser: isCurrentUser,
        );

  // Factory method to convert JSON to ProfileModel
  factory ProfileModel.fromJson(Map<String, dynamic> json) {
    return ProfileModel(
      id: json['id'],
      username: json['username'],
      fullName: json['fullName'],
      bio: json['bio'],
      profileImageUrl: json['profileImageUrl'],
      coverImageUrl: json['coverImageUrl'],
      postsCount: json['postsCount'],
      followersCount: json['followersCount'],
      followingCount: json['followingCount'],
      photos: List<String>.from(json['photos']),
      videos: List<String>.from(json['videos']),
      highlights: List<String>.from(json['highlights']),
      isCurrentUser: json['isCurrentUser'] ?? false,
    );
  }

  // Method to convert ProfileModel to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'fullName': fullName,
      'bio': bio,
      'profileImageUrl': profileImageUrl,
      'coverImageUrl': coverImageUrl,
      'postsCount': postsCount,
      'followersCount': followersCount,
      'followingCount': followingCount,
      'photos': photos,
      'videos': videos,
      'highlights': highlights,
      'isCurrentUser': isCurrentUser,
    };
  }

  // Convert ProfileModel to ProfileEntity (Domain Entity)
  ProfileEntity toEntity() {
    return ProfileEntity(
      id: id,
      username: username,
      fullName: fullName,
      bio: bio,
      profileImageUrl: profileImageUrl,
      coverImageUrl: coverImageUrl,
      postsCount: postsCount,
      followersCount: followersCount,
      followingCount: followingCount,
      photos: photos,
      videos: videos,
      highlights: highlights,
      isCurrentUser: isCurrentUser,
    );
  }
}
