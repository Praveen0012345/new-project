// lib/feature/reels/data/models/reels_model.dart
import 'package:socialapp/feature/reels/domain/reel_entity.dart';

class ReelsModel extends ReelEntity {
  ReelsModel({
    String? id,
    String? title,
    String? description,
    String? image,
    String? video,
    String? userId,
  }) : super(
          id: id,
          title: title,
          description: description,
          image: image,
          video: video,
          userId: userId,
        );

  // Factory method to convert JSON to ReelsModel
  factory ReelsModel.fromJson(Map<String, dynamic> json) {
    return ReelsModel(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      image: json['image'],
      video: json['video'],
      userId: json['userId'],
    );
  }

  // Method to convert ReelsModel to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'image': image,
      'video': video,
      'userId': userId,
    };
  }

  // Convert ReelsModel to ReelEntity (Domain Entity)
  ReelEntity toEntity() {
    return ReelEntity(
      id: id,
      title: title,
      description: description,
      image: image,
      video: video,
      userId: userId,
    );
  }
}
