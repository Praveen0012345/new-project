import 'package:socialapp/feature/reels/data/reels_model.dart';

abstract class ReelsDatasources {
  Future<List<ReelsModel>> getallReels();
  Future<List<ReelsModel>> getallReelsById(String id);

}
