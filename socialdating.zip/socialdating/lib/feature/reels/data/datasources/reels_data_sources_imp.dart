
import 'package:dio/dio.dart';
import 'package:socialapp/feature/reels/data/datasources/reels_datasources.dart';
import 'package:socialapp/feature/reels/data/reels_model.dart';

class ReelsDataSourcesImp extends ReelsDatasources{
  final Dio dio;
  ReelsDataSourcesImp(this.dio);
  @override
  Future<List<ReelsModel>> getallReels() async{
       try {
      //link of bakend api
      final response = await dio.get('/reels');
      List<ReelsModel> reels = (response.data as List).map((reelData) {
        return ReelsModel.fromJson(reelData);
      }).toList();
      return reels;
    } catch (error) {
      throw Exception('Failed to load reels: $error');
    }
  }

  // Fetch a specific reel by its ID from the backend
  @override
  Future<List<ReelsModel>> getallReelsById(String id) async {
    try {
      final response = await dio.get('/reels/$id');
      return [ReelsModel.fromJson(response.data)];
    } catch (error) {
      throw Exception('Failed to load reel: $error');
    }
  }
  
  
  }
