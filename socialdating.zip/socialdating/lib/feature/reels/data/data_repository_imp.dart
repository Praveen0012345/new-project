import 'package:socialapp/feature/reels/data/datasources/reels_data_sources_imp.dart';
import 'package:socialapp/feature/reels/domain/reel_entity.dart';
import 'package:socialapp/feature/reels/domain/reels_repository.dart';

class DataRepositoryImp extends ReelsRepository {
  final ReelsDataSourcesImp reelsDataSourcesImp;
  DataRepositoryImp(this.reelsDataSourcesImp);
  @override
  Future<void> addComment(String id, String comment) {
    // TODO: implement addComment
    throw UnimplementedError();
  }

  @override
  Future<void> deleteReel(String id) {
    // TODO: implement deleteReel
    throw UnimplementedError();
  }

  @override
  Future<List<ReelEntity>> getAllReels() async {
    final reels = await reelsDataSourcesImp.getallReels();
    return reels.map((reel) => reel as ReelEntity).toList();
  }

  @override
  Future<ReelEntity> getReelById(String id) async {
    final reels = await reelsDataSourcesImp.getallReelsById(id);
    return reels as ReelEntity;
  }

  @override
  Future<void> likeReel(String id) {
    // TODO: implement likeReel
    throw UnimplementedError();
  }

  @override
  Future<void> shareReel(String id) {
    // TODO: implement shareReel
    throw UnimplementedError();
  }

  @override
  Future<void> saveReels(String id) {
    // TODO: implement saveReels
    throw UnimplementedError();
  }
}
