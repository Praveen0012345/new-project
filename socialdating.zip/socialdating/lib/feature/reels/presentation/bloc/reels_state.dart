part of 'reels_bloc.dart';

sealed class ReelsState extends Equatable {
  const ReelsState();
  
  @override
  List<Object> get props => [];
}

final class ReelsInitial extends ReelsState {}
