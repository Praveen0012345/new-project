import 'package:socialapp/feature/reels/domain/reel_entity.dart';
import 'package:socialapp/feature/reels/domain/reels_repository.dart';

class ReelsUsecases {
  final ReelsRepository repository;

  ReelsUsecases(this.repository);

  Future<List<ReelEntity>> getallReels()async{
    return await repository.getAllReels();
  }

  Future getallReelsById(getallReelsByIdParams params){
    return repository.getReelById(params.id);
  }
}

class getallReelsByIdParams {
  String id;
  getallReelsByIdParams({required this.id});
}
