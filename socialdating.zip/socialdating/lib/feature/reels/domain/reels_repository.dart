import 'package:socialapp/feature/reels/domain/reel_entity.dart';

abstract class ReelsRepository {
  Future<List<ReelEntity>> getAllReels();
  Future<ReelEntity> getReelById(String id);
  Future<void> likeReel(String id);
  Future<void> shareReel(String id);
  Future<void> addComment(String id, String comment);
  Future<void> deleteReel(String id);
  Future<void> saveReels(String id);
}
