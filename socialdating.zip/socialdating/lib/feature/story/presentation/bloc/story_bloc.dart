import 'package:flutter_bloc/flutter_bloc.dart';


import 'package:socialapp/feature/story/domain/entites.dart';
import 'package:socialapp/feature/story/domain/usecases.dart';

part 'story_event.dart';
part 'story_state.dart';

class StoryBloc extends Bloc<StoryEvent, StoryState> {
  final StoryUsecases usecases;
  
  StoryBloc(this.usecases) : super(StoryLoadingState()) {
    on<LoadStoriesEvent>((event, emit) async {
      emit(StoryLoadingState());
      try {
        final stories = await( await usecases.getstory(Fetchstoryparams(userId: event.userId)));
        emit(StoryLoadedState(stories));
      } catch (e) {
        emit(StoryErrorState(e.toString()));
      }
    });
  }
}
