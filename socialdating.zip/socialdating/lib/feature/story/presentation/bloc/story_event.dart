part of 'story_bloc.dart';

abstract class StoryEvent {}

class LoadStoriesEvent extends StoryEvent {

  final String userId;
  LoadStoriesEvent(this.userId);
}
