part of 'story_bloc.dart';

abstract class StoryState {}

class StoryLoadingState extends StoryState {}

class StoryLoadedState extends StoryState {
  final List<Story> stories;

  StoryLoadedState(this.stories);
}

class StoryErrorState extends StoryState {
  final String message;

  StoryErrorState(this.message);
}
