import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:socialapp/feature/story/domain/entites.dart';
import 'package:socialapp/feature/story/presentation/bloc/story_bloc.dart';

class StoryList extends StatelessWidget {
  const StoryList({super.key, required List<Story> stories});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<StoryBloc, StoryState>(
      builder: (context, state) {
        if (state is StoryLoadingState) {
          return const Center(child: CircularProgressIndicator());
        } else if (state is StoryLoadedState) {
          return SizedBox(
            height: 100,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: state.stories.length,
              itemBuilder: (context, index) {
                final Story story = state.stories[index];
                return Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.all(8),
                      width: 70,
                      height: 70,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                          image: NetworkImage(story.url),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    Text(story.username, style: const TextStyle(fontSize: 12)),
                  ],
                );
              },
            ),
          );
        } else if (state is StoryErrorState) {
          return Center(child: Text(state.message));
        }
        return const SizedBox.shrink();
      },
    );
  }
}
 