class Story {
  final String id;
  final String username;
  final String url;
  final String userProfileUrl;
  final String createdAt;
  final bool isViewed;
  Story( {
    required this.id,
    required this.username,
    required this.userProfileUrl,
    required this.createdAt,
    required this.isViewed,
    required this.url
  });
} 
