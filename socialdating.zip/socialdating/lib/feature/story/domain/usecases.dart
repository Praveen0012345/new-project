
import 'package:socialapp/feature/story/data/repository.dart';
import 'package:socialapp/feature/story/domain/entites.dart';

class StoryUsecases {
  final StoryRepositoryImpl repository;
  StoryUsecases(this.repository);

  Future<List<Story>> getstory(Fetchstoryparams params) async {
    return repository.fetchStories(userId: params.userId);
  }
}

class Fetchstoryparams {
  final String userId;

  Fetchstoryparams({required this.userId});
}


class Uploadstoryparams {
  final Story story;  
  final String filePath;
  Uploadstoryparams(this.filePath, {required this.story});
}