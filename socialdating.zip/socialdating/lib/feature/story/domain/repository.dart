

import 'package:socialapp/feature/story/domain/entites.dart';

abstract class StoryRepository {
  Future<List<Story>> fetchStories({required String userId});
  Future<void> uploadstory({required Story story, required String filePath});
}