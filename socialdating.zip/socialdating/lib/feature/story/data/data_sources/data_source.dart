import 'package:socialapp/feature/story/data/models.dart';


abstract class DataSources {
  Future<List<StoryModel>> fetchstories();
  Future<String> uploadstory({required String filePath, required StoryModel story});
  Future<void> uploadstorydrtails({required StoryModel story});
}
