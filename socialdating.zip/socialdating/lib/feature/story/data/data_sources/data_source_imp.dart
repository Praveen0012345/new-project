import 'package:dio/dio.dart';
import 'package:socialapp/feature/story/data/data_sources/data_source.dart';
import 'package:socialapp/feature/story/data/models.dart';


class DataSourceImp extends DataSources {
  
  final Dio dio;

  DataSourceImp(this.dio);

  @override
  Future<List<StoryModel>> fetchstories() async {
   final response = await dio.get("");
    if(response.statusCode == 200){
      List<dynamic> data = response.data;
      return data.map((json) => StoryModel.fromJson(json)).toList();
    }else{
      return [];
    }
  }
  
  @override
   Future<String> uploadstory({required String filePath, required StoryModel story}) async {
    try {
      String fileName = filePath.split('/').last;

      // Prepare file upload
      FormData formData = FormData.fromMap({
        "file": await MultipartFile.fromFile(filePath, filename: fileName),
      });

      final response = await dio.post(
        "https://your-backend-api/upload", // Replace with your file upload endpoint
        data: formData,
      );

      if (response.statusCode == 200) {
        // Return the uploaded file URL
        return response.data['fileUrl'];
      } else {
        throw Exception("File upload failed");
      }
    } catch (e) {
      throw Exception("Error uploading file: $e");
    }
  }
  
  @override
  Future<void> uploadstorydrtails({required StoryModel story}) async {
   try {
      final response = await dio.post(
        //link of the backend api
        "https://your-backend-api/posts",
        data: story.toJson(),
      );

      if (response.statusCode != 200) {
        throw Exception("Failed to upload post details");
      }
    } catch (e) {
      throw Exception("Error uploading post details: $e");
    }
  }


  }
 