// lib/feature/story/data/models/story_model.dart
import 'package:socialapp/feature/story/domain/entites.dart';


class StoryModel extends Story {
  StoryModel({
    required String id,
    required String username,
    required String url,
    required String userProfileUrl,
    required String createdAt,
    required bool isViewed,
  }) : super(
          id: id,
          username: username,
          url: url,
          userProfileUrl: userProfileUrl,
          createdAt: createdAt,
          isViewed: isViewed,
        );

  // Factory method to convert JSON to StoryModel
  factory StoryModel.fromJson(Map<String, dynamic> json) {
    return StoryModel(
      id: json['id'] as String,
      username: json['username'] as String,
      url: json['url'] as String,
      userProfileUrl: json['userProfileUrl'] as String,
      createdAt: json['createdAt'] as String,
      isViewed: json['isViewed'] as bool,
    );
  }

  // Method to convert StoryModel to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'url': url,
      'userProfileUrl': userProfileUrl,
      'createdAt': createdAt,
      'isViewed': isViewed,
    };
  }

  // Convert StoryModel to Story (Domain Entity)
  Story toEntity() {
    return Story(
      id: id,
      username: username,
      url: url,
      userProfileUrl: userProfileUrl,
      createdAt: createdAt,
      isViewed: isViewed,
    );
  }
}
