import 'package:socialapp/feature/story/data/data_sources/data_source_imp.dart';
import 'package:socialapp/feature/story/data/models.dart';
import 'package:socialapp/feature/story/domain/entites.dart';
import 'package:socialapp/feature/story/domain/repository.dart';

class StoryRepositoryImpl extends StoryRepository {
  final DataSourceImp dataSources;
  StoryRepositoryImpl(
    this.dataSources,
  ) : super();
  @override
  Future<List<Story>> fetchStories({required String userId}) {
    return dataSources.fetchstories();
  }

  @override
  Future<void> uploadstory({required Story story, required String filePath}) {
    try{
      final storymodel = StoryModel(
        id: story.id,
        username: story.username,
        url: story.url,
        createdAt: story.createdAt,
        isViewed: story.isViewed,
        userProfileUrl: story.userProfileUrl);
        return dataSources.uploadstory(story: storymodel, filePath: filePath);
        } catch (e) {
          throw Exception(e.toString());
          
    }


  }
}
