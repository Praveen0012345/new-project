enum NotificationType {
  like,
  comment,
  follow,
  storyLike,
}

class NotificationEntity {
  final String id;
  final String userId;
  final String username;
  final String userProfileUrl;
  final NotificationType type;
  final String? postId;
  final String? postImageUrl;
  final String? comment;
  final List<String>? otherUsernames;
  final DateTime createdAt;
  final bool isRead;

  NotificationEntity({
    required this.id,
    required this.userId,
    required this.username,
    required this.userProfileUrl,
    required this.type,
    this.postId,
    this.postImageUrl,
    this.comment,
    this.otherUsernames,
    required this.createdAt,
    required this.isRead,
  });

  String get notificationText {
    switch (type) {
      case NotificationType.like:
        if (otherUsernames != null && otherUsernames!.isNotEmpty) {
          return 'liked by $username${otherUsernames!.isNotEmpty ? " and ${otherUsernames!.length} others" : ""}';
        }
        return 'liked by $username';
      case NotificationType.comment:
        return 'commented by $username';
      case NotificationType.follow:
        return 'started following by $username';
      case NotificationType.storyLike:
        if (otherUsernames != null && otherUsernames!.isNotEmpty) {
          return 'liked story by $username${otherUsernames!.isNotEmpty ? ", ${otherUsernames!.join(", ")} and others" : ""}';
        }
        return 'liked story by $username';
    }
  }
}
