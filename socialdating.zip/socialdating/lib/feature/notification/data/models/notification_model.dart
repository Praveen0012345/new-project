import '../../domain/entities/notification_entity.dart';

class NotificationModel extends NotificationEntity {
  NotificationModel({
    required super.id,
    required super.userId,
    required super.username,
    required super.userProfileUrl,
    required super.type,
    super.postId,
    super.postImageUrl,
    super.comment,
    super.otherUsernames,
    required super.createdAt,
    required super.isRead,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      id: json['id'] as String,
      userId: json['userId'] as String,
      username: json['username'] as String,
      userProfileUrl: json['userProfileUrl'] as String,
      type: NotificationType.values.firstWhere(
        (e) => e.toString() == 'NotificationType.${json['type']}',
      ),
      postId: json['postId'] as String?,
      postImageUrl: json['postImageUrl'] as String?,
      comment: json['comment'] as String?,
      otherUsernames: json['otherUsernames'] != null
          ? List<String>.from(json['otherUsernames'])
          : null,
      createdAt: DateTime.parse(json['createdAt'] as String),
      isRead: json['isRead'] as bool,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'username': username,
      'userProfileUrl': userProfileUrl,
      'type': type.toString().split('.').last,
      'postId': postId,
      'postImageUrl': postImageUrl,
      'comment': comment,
      'otherUsernames': otherUsernames,
      'createdAt': createdAt.toIso8601String(),
      'isRead': isRead,
    };
  }
}
