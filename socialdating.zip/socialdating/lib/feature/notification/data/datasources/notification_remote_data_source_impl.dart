import 'package:dio/dio.dart';
import '../models/notification_model.dart';
import 'notification_remote_data_source.dart';

class NotificationRemoteDataSourceImpl implements NotificationRemoteDataSource {
  final Dio dio;
  final String baseUrl;

  NotificationRemoteDataSourceImpl({
    required this.dio,
    required this.baseUrl,
  });

  @override
  Future<List<NotificationModel>> getNotifications() async {
    try {
      final response = await dio.get('$baseUrl/notifications');
      return (response.data['notifications'] as List)
          .map((json) => NotificationModel.fromJson(json))
          .toList();
    } catch (e) {
      throw Exception('Failed to load notifications');
    }
  }

  @override
  Future<void> markAsRead(String notificationId) async {
    try {
      await dio.patch(
        '$baseUrl/notifications/$notificationId/read',
      );
    } catch (e) {
      throw Exception('Failed to mark notification as read');
    }
  }

  @override
  Future<void> markAllAsRead() async {
    try {
      await dio.patch(
        '$baseUrl/notifications/read-all',
      );
    } catch (e) {
      throw Exception('Failed to mark all notifications as read');
    }
  }

  @override
  Stream<List<NotificationModel>> getNotificationsStream() {
    // Implement WebSocket or Server-Sent Events here
    throw UnimplementedError();
  }
}
