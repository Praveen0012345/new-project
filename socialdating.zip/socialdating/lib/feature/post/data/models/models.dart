import 'package:socialapp/feature/post/domain/entities/comment.dart';
import 'package:socialapp/feature/post/domain/entities/entites.dart';

class PostModel {
  final String username;
  final String location;
  final String imageUrl;
  final String caption;
  final String timeAgo;
  final List<int> likes;
  final List<CommentModel> comments;
  final String friendlist;
  final String postid;
  final bool isLiked;
  final bool isSaved;
  final String userProfileUrl;
  final DateTime createdAt;

  PostModel({
    required this.username,
    required this.location,
    required this.imageUrl,
    required this.caption,
    required this.timeAgo,
    required this.likes,
    required this.comments,
    required this.friendlist,
    required this.postid,
    required this.isLiked,
    required this.isSaved,
    required this.userProfileUrl,
    required this.createdAt,
  });

  // Factory method to create an instance from JSON
  factory PostModel.fromJson(Map<String, dynamic> json) {
    return PostModel(
      username: json['username'],
      location: json['location'],
      imageUrl: json['imageUrl'],
      caption: json['caption'],
      timeAgo: json['timeAgo'],
      likes: List<int>.from(json['likes']),
      comments: (json['comments'] as List)
          .map((comment) => CommentModel.fromJson(comment))
          .toList(),
      friendlist: json['friendlist'],
      postid: json['postid'],
      isLiked: json['isLiked'],
      isSaved: json['isSaved'],
      userProfileUrl: json['userProfileUrl'],
      createdAt: DateTime.parse(json['createdAt']),
    );
  }

  // Method to convert the instance to JSON
  Map<String, dynamic> toJson() => {
        'username': username,
        'location': location,
        'imageUrl': imageUrl,
        'caption': caption,
        'timeAgo': timeAgo,
        'likes': likes,
        'comments': comments.map((comment) => comment.toJson()).toList(),
        'friendlist': friendlist,
        'postid': postid,
        'isLiked': isLiked,
        'isSaved': isSaved,
        'userProfileUrl': userProfileUrl,
        'createdAt': createdAt.toIso8601String(),
      };

  // Method to convert PostModel to Post (Domain Layer Entity)
  Post toEntity() {
    return Post(
      username: username,
      location: location,
      imageUrl: imageUrl,
      caption: caption,
      timeAgo: timeAgo,
      likes: likes,
      comments: comments.map((comment) => comment.toEntity()).toList(),
      friendlist: friendlist,
      postid: postid,
      isLiked: isLiked,
      isSaved: isSaved,
      userProfileUrl: userProfileUrl,
      createdAt: createdAt,
    );
  }

  // Method to create a PostModel from Post (Entity)
  static PostModel fromEntity(Post post) {
    return PostModel(
      username: post.username,
      location: post.location,
      imageUrl: post.imageUrl,
      caption: post.caption,
      timeAgo: post.timeAgo,
      likes: post.likes,
      comments: post.comments.map((comment) => CommentModel.fromEntity(comment)).toList(),
      friendlist: post.friendlist,
      postid: post.postid,
      isLiked: post.isLiked,
      isSaved: post.isSaved,
      userProfileUrl: post.userProfileUrl,
      createdAt: post.createdAt,
    );
  }
}


class CommentModel {
  final String id;
  final String userId;
  final String username;
  final String text;
  final DateTime createdAt;

  CommentModel({
    required this.id,
    required this.userId,
    required this.username,
    required this.text,
    required this.createdAt,
  });

  factory CommentModel.fromJson(Map<String, dynamic> json) {
    return CommentModel(
      id: json['id'],
      userId: json['userId'],
      username: json['username'],
      text: json['text'],
      createdAt: DateTime.parse(json['createdAt']),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'userId': userId,
        'username': username,
        'text': text,
        'createdAt': createdAt.toIso8601String(),
      };

  Comment toEntity() {
    return Comment(
      id: id,
      userId: userId,
      username: username,
      text: text,
      createdAt: createdAt,
    );
  }

  static CommentModel fromEntity(Comment comment) {
    return CommentModel(
      id: comment.id,
      userId: comment.userId,
      username: comment.username,
      text: comment.text,
      createdAt: comment.createdAt,
    );
  }
}
