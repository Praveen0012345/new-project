// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:dio/dio.dart';

import 'package:socialapp/feature/post/data/datasources/data_source.dart';
import 'package:socialapp/feature/post/data/models/models.dart';

class DataSourcesImpl extends PostRemoteDataSource {
  final Dio dio;
  DataSourcesImpl(
    this.dio,
  );

  // ftch posts from the api
  @override
  Future<List<PostModel>> fetchPosts() async {
    final response = await dio.get("");
    try {
      if (response.statusCode == 200) {
        List<PostModel> posts = (response.data as List)
            .map((data) => PostModel.fromJson(data))
            .toList();
        return posts;
      } else {
        return [];
      }
    } catch (e) {
      throw Exception("Failed to fetch posts: $e");
    }
  }

  // upload file to the cloud storage and return the url
  @override
  Future<String> uploadFile({required String filePath}) async {
    try {
      String fileName = filePath.split('/').last;

      // Prepare file upload
      FormData formData = FormData.fromMap({
        "file": await MultipartFile.fromFile(filePath, filename: fileName),
      });

      final response = await dio.post(
        "https://your-backend-api/upload", // Replace with your file upload endpoint
        data: formData,
      );

      if (response.statusCode == 200) {
        // Return the uploaded file URL
        return response.data['fileUrl'];
      } else {
        throw Exception("File upload failed");
      }
    } catch (e) {
      throw Exception("Error uploading file: $e");
    }
  }

  @override
  Future<void> uploadPostDetails({required PostModel post}) async {
    try {
      final response = await dio.post(
        //link of the backend api
        "https://your-backend-api/posts",
        data: post.toJson(),
      );

      if (response.statusCode != 200) {
        throw Exception("Failed to upload post details");
      }
    } catch (e) {
      throw Exception("Error uploading post details: $e");
    }
  }

  @override
  Future<void> addComment(String postId, String comment) async{
   try {
      final response = await dio.post(
        'baseUrl/posts/$postId/comments',
        data: {'text': comment},
      ); //link of addcomment
      
      if (response.statusCode != 201) {
        throw Exception('Failed to add comment');
      }
    } catch (e) {
      throw Exception('Failed to add comment: $e');
    }
  }

  @override
  Future<void> deleteComment(String postId, String commentId) async {
    try {
      final response = await dio.delete(
        'baseUrl/posts/$postId/comments/$commentId',
      ); // link of deletecomment

      if (response.statusCode != 200) {
        throw Exception('Failed to delete comment');
      }
    } catch (e) {
      throw Exception('Failed to delete comment: $e');
    }
  }
    @override
    Future<void> likePost(String postId) async {
      try {
        final response = await dio.post(''); //link of likepost

        if (response.statusCode != 200) {
          throw Exception('Failed to like post');
        }
      } catch (e) {
        throw Exception('Failed to like post: $e');
      }
    }

    @override
    Future<void> savePost(String postId) async {
      try {
        final response =
            await dio.post('baseUrl/posts/$postId/save'); //link of save post

        if (response.statusCode != 200) {
          throw Exception('Failed to save post');
        }
      } catch (e) {
        throw Exception('Failed to save post: $e');
      }
    }

    @override
    Future<void> sharePost(String postId) async {
      try {
        final response =
            await dio.post('baseUrl/posts/$postId/share'); // link of sharepost

        if (response.statusCode != 200) {
          throw Exception('Failed to share post');
        }
      } catch (e) {
        throw Exception('Failed to share post: $e');
      }
    }

    @override
    Future<void> unlikePost(String postId) async {
      try {
        final response = await dio.delete(''); //link of unlikepost

        if (response.statusCode != 200) {
          throw Exception('Failed to unlike post');
        }
      } catch (e) {
        throw Exception('Failed to unlike post: $e');
      }
    }

    @override
    Future<void> unsavePost(String postId) async {
      try {
        final response = await dio
            .delete('baseUrl/posts/$postId/save'); //link of unsavespost

        if (response.statusCode != 200) {
          throw Exception('Failed to unsave post');
        }
      } catch (e) {
        throw Exception('Failed to unsave post: $e');
      }
    }
    
      @override
      Future<void> createpost() {
    // TODO: implement createpost
    throw UnimplementedError();
      }
    
      @override
      Future<void> detetepost() {
    // TODO: implement detetepost
    throw UnimplementedError();
      }
    
      @override
      Future<void> updatepost() {
    // TODO: implement updatepost
    throw UnimplementedError();
      }
  }

