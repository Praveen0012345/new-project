import 'package:socialapp/feature/post/data/models/models.dart';

abstract class PostRemoteDataSource {
  /// Fetch all posts from the backend
  Future<List<PostModel>> fetchPosts();

  /// Upload a file (like an image) to cloud storage or a server
  Future<String> uploadFile({required String filePath});

  /// Upload post details to the backend
  Future<void> uploadPostDetails({required PostModel post});
  Future<void> likePost(String postId);
  Future<void> unlikePost(String postId);
  Future<void> savePost(String postId);
  Future<void> unsavePost(String postId);
  Future<void> addComment(String postId, String comment);
  Future<void> deleteComment(String postId, String commentId);
  Future<void> sharePost(String postId);
  Future<void> detetepost();
  Future<void> createpost();
  Future<void> updatepost();
}
