import 'package:socialapp/feature/post/data/datasources/data_sources_impl.dart';
import 'package:socialapp/feature/post/data/models/models.dart';
import 'package:socialapp/feature/post/domain/entities/entites.dart';
import 'package:socialapp/feature/post/domain/repository.dart';

class PostRepositoryImpl extends PostRepository {
  final DataSourcesImpl remotedataSources;

  PostRepositoryImpl(this.remotedataSources);

  @override
  Future<List<Post>> fetchPost({required String id})async {
    // return remotedataSources
    //     .fetchPosts()
    //     .then((post) => post.toEntity())
    //     .toList();
    try {
      // Fetch posts from remote data source
      List<PostModel> postModels = await remotedataSources.fetchPosts();

      // Convert PostModel instances to Post entities
      List<Post> posts = postModels.map((postModel) => postModel.toEntity()).toList();

      return posts;
    } catch (e) {
      throw Exception("Error in repository while fetching posts: $e");
    }
  }

  @override
  Future<Post> uploadpost(
      {required Post post, required String filePath}) async {
    try {
      // Upload the file and get the file URL
      String fileUrl = await remotedataSources.uploadFile(filePath: filePath);

      // Create a PostModel with the uploaded file URL
      PostModel newPost = PostModel(
          username: post.username,
          location: post.location,
          imageUrl: fileUrl, // Add the uploaded file URL here
          caption: post.caption,
          timeAgo: DateTime.now().toString(),
          likes: post.likes,
          comments: post.comments
              .map((comment) => CommentModel(
                    id: comment.id,
                    userId: comment.userId,
                    username: comment.username,
                    text: comment.text,
                    createdAt: comment.createdAt,
                  ))
              .toList(),
          friendlist: post.friendlist,
          postid: post.postid,
          isLiked: post.isLiked,
          isSaved: post.isSaved,
          userProfileUrl: post.userProfileUrl,
          createdAt: post.createdAt);

      // Upload post details to the backend
      await remotedataSources.uploadPostDetails(post: newPost);
      return newPost.toEntity();
    } catch (e) {
      throw Exception("Error in repository while uploading post: $e");
    }
  }

  @override
  Future<void> deletePost(String postId) async {
    // TODO: implement deletePost
    throw UnimplementedError();
  }

  @override
  Future<void> likePost(String postId) async {
    try {
      await remotedataSources.likePost(postId);
    } catch (e) {
      throw Exception("Error in repository while liking post: $e");
    }
  }

  @override
  Future<void> unlikePost(String postId) async {
    try {
      await remotedataSources.unlikePost(postId);
    } catch (e) {
      throw Exception("Error in repository while unliking post: $e");
    }
  }

  @override
  Future<void> addComment(String postId, String comment) async {
    try {
      await remotedataSources.addComment(postId, comment);
    } catch (e) {
      throw Exception("Error in repository while adding comment: $e");
    }
  }

  @override
  Future<void> deleteComment(String postId, String commentId) async {
    try {
      await remotedataSources.deleteComment(postId, commentId);
    } catch (e) {
      throw Exception("Error in repository while deleting comment: $e");
    }
  }

  @override
  Future<void> savePost(String postId) async {
    try {
      await remotedataSources.savePost(postId);
    } catch (e) {
      throw Exception("Error in repository while saving post: $e");
    }
  }

  @override
  Future<void> sharePost(String postId) async {
    try {
      await remotedataSources.sharePost(postId);
    } catch (e) {
      throw Exception("Error in repository while sharing post: $e");
    }
  }

  @override
  Future<void> unsavePost(String postId) async {
    try {
      await remotedataSources.unsavePost(postId);
    } catch (e) {
      throw Exception("Error in repository while un saving post: $e");
    }
  }

  @override
  Future<void> createpost({
    required int userid,
    required bool isLogin,
    required String imageUrl,
    required String caption,
  }) {
    // TODO: implement createpost
    throw UnimplementedError();
  }

  @override
  Future<void> updatepost(
      {required String postId,
      required String caption,
      required String location,
      required bool isloging,
      required String imageurl}) {
    // TODO: implement updatepost
    throw UnimplementedError();
  }
}


