import 'package:socialapp/feature/post/domain/entities/entites.dart';

abstract class PostRepository {
  Future<List<Post>> fetchPost({required String id});
  Future<void> uploadpost({required Post post, required String filePath});
  Future<void> likePost(String postId);
  Future<void> unlikePost(String postId);
  Future<void> deletePost(String postId);
  Future<void> savePost(String postId);
  Future<void> unsavePost(String postId);
  Future<void> addComment(String postId, String comment);
  Future<void> deleteComment(String postId, String commentId);
  Future<void> sharePost(String postId);
  Future<void> createpost({
    required int userid,
    required bool isLogin,
    required String imageUrl,
    required String caption,
  });
  Future<void> updatepost({required String postId, required String caption, required String location,
     required bool isloging, required String imageurl, 
     });
}
