import 'package:socialapp/feature/post/domain/entities/entites.dart';
import 'package:socialapp/feature/post/domain/repository.dart';

class PostUsecases {
  final PostRepository postRepository;
  PostUsecases(this.postRepository);

  Future<List<Post>> fetchPost(Fetchpostparams params) async {
    return postRepository.fetchPost(id: params.id);
  }

  Future<void> uploadPost(Uploadpostparams params) async {
    return postRepository.uploadpost(
        post: params.post, filePath: params.filePath);
  }

  Future<void> likePost(String postId) async {
    await postRepository.likePost(postId);
  }

  Future<void> unlikePost(String postId) async {
    await postRepository.unlikePost(postId);
  }

  Future<void> savePost(String postId) async {
    await postRepository.savePost(postId);
  }

  Future<void> unsavePost(String postId) async {
    await postRepository.unsavePost(postId);
  }

  Future<void> addComment(AddCommentParams params) async {
    await postRepository.addComment(params.postId, params.comment);
  }

  Future<void> deleteComment(DeleteCommentParams params) async {
    await postRepository.deleteComment(params.postId, params.commentId);
  }

  Future<void> sharePost(String postId) async {
    await postRepository.sharePost(postId);
  }

  Future<void> createPost(CreatePostParams params) async {
    await postRepository.createpost(
      isLogin: params.isLogin,
      imageUrl: params.imageUrl,
      caption: params.caption,
      userid: params.userId,
    );
  }

  Future<void> updatePost(UpdatePostParams params) async {
    await postRepository.updatepost(
      postId: params.postId,
      caption: params.caption,
      location: params.location,
      imageurl: params.filepath,
      isloging: false,
      
    );
  }

  Future<void> deletePost(String postId) async {
    await postRepository.deletePost(postId);
  }
}

class Fetchpostparams {
  final String id;
  Fetchpostparams({required this.id});
}

class Uploadpostparams {
  
  final String filePath;
  final Post post;
  Uploadpostparams(
      {
      required this.filePath,
      required this.post});
}

class AddCommentParams {
  final String postId;
  final String comment;
  AddCommentParams({required this.postId, required this.comment});
}

class DeleteCommentParams {
  final String postId;
  final String commentId;
  DeleteCommentParams({required this.postId, required this.commentId});
}

class CreatePostParams {
  final String caption;
  final String imageUrl;
  final String? location;
  bool isLogin = false;
  final int userId;
  CreatePostParams(
      {required this.caption,
      required this.imageUrl,
      this.location,
      required this.userId,
      required this.isLogin});
}

class UpdatePostParams {
  final String postId;
  final String caption;
  final String location;
  final String filepath;
  
  UpdatePostParams(
      {required this.postId,
      required this.caption,
      required this.location,
      required this.filepath,
      });
}
