class Comment {
  final String id;
  final String userId;
  final String username;
  final String text;
  final DateTime createdAt;

  Comment(
      {required this.createdAt,
      required this.id,
      required this.text,
      required this.userId,
      required this.username});

  toJson() {}
}
