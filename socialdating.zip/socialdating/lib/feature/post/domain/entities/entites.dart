import 'package:socialapp/feature/post/domain/entities/comment.dart';

class Post {
  final String username;
  final String location;
  final String imageUrl;
  final String userProfileUrl;
  final String caption;
  final String timeAgo;
  final List<int> likes;
  final List<Comment> comments;
  final String friendlist;
  final String postid;
  bool isLiked;
  bool isSaved;
  final DateTime createdAt;
  Post({
    required this.friendlist,
    required this.username,
    required this.location,
    required this.imageUrl,
    required this.caption,
    required this.timeAgo,
    required this.likes,
    required this.comments,
    required this.postid,
    required this.isLiked,
    required this.userProfileUrl,
    required this.isSaved,
    required this.createdAt,
  });

  get id => null;
}
