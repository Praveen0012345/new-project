

import 'package:flutter/material.dart';
import 'package:socialapp/feature/post/domain/entities/entites.dart';
import 'package:socialapp/feature/post/presentation/widgets/post_item.dart';

class PostList extends StatelessWidget {
  final List<Post> posts;

  const PostList({super.key, required this.posts});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: posts.length,
      itemBuilder: (context, index) {
        return PostItem(post: posts[index]);
      },
    );
  }
}
