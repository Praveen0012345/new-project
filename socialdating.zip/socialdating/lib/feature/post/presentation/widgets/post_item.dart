import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:socialapp/feature/home/persentation/bloc/home_bloc.dart';
import 'package:socialapp/feature/post/domain/entities/entites.dart';
import 'package:socialapp/feature/post/presentation/bloc/post_bloc.dart';
import 'package:socialapp/feature/post/presentation/bloc/post_event.dart';

class PostItem extends StatefulWidget {
  final Post post;

  const PostItem({super.key, required this.post});

  @override
  State<PostItem> createState() => _PostItemState();
}

class _PostItemState extends State<PostItem> {
  bool _isLiked = false;
  bool _isSaved = false;

  @override
  void initState() {
    super.initState();
    String _isLiked = widget.post.isLiked;
    _isSaved = widget.post.isSaved;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      elevation: 0,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Post Header
          ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(widget.post.userProfileUrl),
            ),
            title: Text(
              widget.post.username,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text(widget.post.location),
            trailing: IconButton(
              icon: const Icon(Icons.more_vert),
              onPressed: () {},
            ),
          ),

          // Post Image
          GestureDetector(
            onDoubleTap: () {
              if (widget.post.isLiked == true) {
                context.read<PostBloc>().add(LikePostEvent(widget.post.id));
              }
            },
            child: Image.network(
              widget.post.imageUrl,
              fit: BoxFit.cover,
              width: double.infinity,
            ),
          ),

          // Action Buttons
          Row(
            children: [
              IconButton(
                icon: Icon(
                  _isLiked ? Icons.favorite : Icons.favorite_border,
                  color: _isLiked ? Colors.red : null,
                ),
                onPressed: () {
                  setState(() {
                    _isLiked = !_isLiked;
                  });
                  if (widget.post.isLiked == true) {
                    context.read<PostBloc>().add(LikePostEvent(widget.post.id));
                  } else {
                    context
                        .read<PostBloc>()
                        .add(UnlikePost(postId: widget.post.id));
                  }
                },
              ),
              IconButton(
                icon: const Icon(Icons.comment_outlined),
                onPressed: () {
                  // Show comments
                },
              ),
              IconButton(
                icon: const Icon(Icons.share_outlined),
                onPressed: () {
                  context
                      .read<PostBloc>()
                      .add(SharePost(postId: widget.post.id));
                },
              ),
              const Spacer(),
              IconButton(
                icon: Icon(
                  _isSaved ? Icons.bookmark : Icons.bookmark_border,
                ),
                onPressed: () {
                  setState(() {
                    _isSaved = !_isSaved;
                  });
                  if (widget.post.isSaved==true) {
                    context
                        .read<PostBloc>()
                        .add(UnsavePost(postId: widget.post.id));
                  } else {
                    context
                        .read<PostBloc>()
                        .add(SavePost(postId: widget.post.id));
                  }
                },
              ),
            ],
          ),

          // Likes Count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              '${widget.post.likes.length} likes',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),

          // Caption
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: RichText(
              text: TextSpan(
                style: DefaultTextStyle.of(context).style,
                children: [
                  TextSpan(
                    text: '${widget.post.username} ',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  TextSpan(text: widget.post.caption),
                ],
              ),
            ),
          ),

          // Comments
          if (widget.post.comments.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'View all ${widget.post.comments.length} comments',
                style: TextStyle(color: Colors.grey[600]),
              ),
            ),

          // Timestamp
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              _getTimeAgo(widget.post.createdAt),
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getTimeAgo(DateTime dateTime) {
    final difference = DateTime.now().difference(dateTime);
    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m ago';
    } else {
      return 'Just now';
    }
  }
}
