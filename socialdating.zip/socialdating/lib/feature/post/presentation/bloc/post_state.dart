part of 'post_bloc.dart';

abstract class PostState extends Equatable {
  const PostState();

  @override
  List<Object?> get props => [];
}

class PostInitial extends PostState {
  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class PostLoading extends PostState {
  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class PostLoaded extends PostState {
  final List<Post> posts;

  const PostLoaded(this.posts);

  @override
  List<Object?> get props => [posts];
}

class PostError extends PostState {
  final String message;

  const PostError(this.message);

  @override
  List<Object?> get props => [message];
}

class PostSuccess extends PostState {
  final String message;

  const PostSuccess(this.message);
}

class PostLikedState extends PostState {}

class PostunLikedState extends PostState {}

class PostSuccessSavedState extends PostState {}

class PostUnsavedState extends PostState {}

class PostSuccesAddCommentState extends PostState {}

class PostSuccessDeleteCommentState extends PostState {}

class PostShareState extends PostState {}
