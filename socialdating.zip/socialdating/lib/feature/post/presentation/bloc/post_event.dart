import 'package:equatable/equatable.dart';
import 'package:socialapp/feature/post/domain/entities/entites.dart';

abstract class PostEvent extends Equatable {
  const PostEvent();

  @override
  List<Object?> get props => [];
}

class FetchPostsEvent extends PostEvent {
  final String userId;
  final List<Post> posts;

  const FetchPostsEvent({required this.posts, required this.userId});
}

class CreatePostEvent extends PostEvent {
  final String filepath;
  final Post post;

  const CreatePostEvent({
    required this.post,
    required this.filepath,
  });

  @override
  List<Object?> get props => [
        post,
        filepath,
      ];
}

class UpdatePostEvent extends PostEvent {
  final String postId;
  final String caption;
  final String location;
  final String? filepath;
  final bool isloging;

  const UpdatePostEvent(
      {required this.postId,
      required this.caption,
      required this.location,
      required this.filepath,
      required this.isloging
      });

  @override
  List<Object?> get props => [postId, caption, location];
}

class DeletePostEvent extends PostEvent {
  final String postId;

  const DeletePostEvent(this.postId);

  @override
  List<Object?> get props => [postId];
}

class LikePostEvent extends PostEvent {
  final String postId;

  const LikePostEvent(this.postId);

  @override
  List<Object?> get props => [postId];
}

class CommentPostEvent extends PostEvent {
  final String postId;
  final String comment;

  const CommentPostEvent({
    required this.postId,
    required this.comment,
  });

  @override
  List<Object?> get props => [postId, comment];
}

class FetchPostEvent extends PostEvent {
  final int id;

  const FetchPostEvent({
    required this.id,
  });

  @override
  List<Object?> get props => [id];
}

class UploadPostEvent extends PostEvent {
  final Post post;
  final String filePath;

  const UploadPostEvent({
    required this.post,
    required this.filePath,
  });

  @override
  List<Object?> get props => [post, filePath];
}

class UnlikePost extends PostEvent {
  final String postId;

  const UnlikePost({required this.postId});

  @override
  List<Object?> get props => [postId];
}

class SavePost extends PostEvent {
  final String postId;

  const SavePost({required this.postId});

  @override
  List<Object?> get props => [postId];
}

class UnsavePost extends PostEvent {
  final String postId;

  const UnsavePost({required this.postId});

  @override
  List<Object?> get props => [postId];
}

class AddComment extends PostEvent {
  final String postId;
  final String comment;

  const AddComment({required this.postId, required this.comment});

  @override
  List<Object?> get props => [postId, comment];
}

class DeleteComment extends PostEvent {
  final String postId;
  final String commentId;

  const DeleteComment({required this.postId, required this.commentId});

  @override
  List<Object?> get props => [postId, commentId];
}

class SharePost extends PostEvent {
  final String postId;

  const SharePost({required this.postId});

  @override
  List<Object?> get props => [postId];
}

