


import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:socialapp/feature/post/domain/entities/entites.dart';

import 'package:socialapp/feature/post/domain/usecases.dart';
import 'package:socialapp/feature/post/presentation/bloc/post_event.dart';


part 'post_state.dart';

class PostBloc extends Bloc<PostEvent, PostState> {
  final PostUsecases usecases;

  PostBloc({required this.usecases}) : super(PostInitial()) {
    on<FetchPostsEvent>(_onFetchPosts);
    on<CreatePostEvent>(_onCreatePost);
    on<UpdatePostEvent>(_onUpdatePost);
    on<DeletePostEvent>(_onDeletePost);
    on<LikePostEvent>(_onLikePost);
    on<CommentPostEvent>(_onCommentPost);
    on<UnlikePost>(_onUnlikePost);
    on<SavePost>(_onSavePost);
    on<UnsavePost>(_onUnsavePost);
    on<AddComment>(_onAddComment);
    on<DeleteComment>(_onDeleteComment);
    on<SharePost>(_onSharePost);
  }

  Future<void> _onFetchPosts(FetchPostsEvent event, Emitter<PostState> emit) async {
    try {
      emit(PostLoading());
      final posts = await usecases.fetchPost(
        Fetchpostparams(id: event.userId),
      );
      emit(PostLoaded(posts));
    } catch (e) {
      emit(PostError(e.toString()));
    }
  }

  Future<void> _onCreatePost(CreatePostEvent event, Emitter<PostState> emit) async {
    try {
      emit(PostLoading());
      await usecases.uploadPost(
        Uploadpostparams(post: event.post, filePath: event.filepath),
      );
      final posts = await usecases.fetchPost(Fetchpostparams(id: event.post.id));
      emit(PostLoaded(posts));
    } catch (e) {
      emit(PostError(e.toString()));
    }
  }

  Future<void> _onUpdatePost(UpdatePostEvent event, Emitter<PostState> emit) async {
    try {
      emit(PostLoading());
      if (event.filepath != null  ) {
        await usecases.updatePost(
        UpdatePostParams(postId: event.postId, caption: event.caption, location: event.location, filepath: event.filepath!),
      );
      }
      final posts = await usecases.fetchPost(Fetchpostparams(id: event.postId));
      emit(PostLoaded(posts));
    } catch (e) {
      emit(PostError(e.toString()));
    }
  }

  Future<void> _onDeletePost(DeletePostEvent event, Emitter<PostState> emit) async {
    try {
      emit(PostLoading());
      await usecases.deletePost(event.postId);
      final posts = await usecases.fetchPost(Fetchpostparams(id: event.postId));
      emit(PostLoaded(posts));
    } catch (e) {
      emit(PostError(e.toString()));
    }
  }

  Future<void> _onLikePost(LikePostEvent event, Emitter<PostState> emit) async {
    try {
      emit(PostLoading());
      await usecases.likePost(event.postId);
      // final posts = await usecases.likePost(event.postId);
      emit(PostLikedState());
    } catch (e) {
      emit(PostError(e.toString()));
    }
  }

  Future<void> _onCommentPost(CommentPostEvent event, Emitter<PostState> emit) async {
    try {
      emit(PostLoading());
      await usecases.addComment(
        AddCommentParams(postId: event.postId, comment: event.comment),
      );
      final posts = await usecases.fetchPost(Fetchpostparams(id: event.postId));
      emit(PostLoaded(posts));
    } catch (e) {
      emit(PostError(e.toString()));
    }
  }

  Future<void> _onUnlikePost(UnlikePost event, Emitter<PostState> emit) async {
    try {
      emit(PostLoading());
      await usecases.unlikePost(event.postId);
      // final posts = await usecases.unlikePost(event.postId);
      emit(PostunLikedState());
    } catch (e) {
      emit(PostError(e.toString()));
    }
  }

  Future<void> _onSavePost(SavePost event, Emitter<PostState> emit) async {
    try {
      emit(PostLoading());
      await usecases.savePost(event.postId);
      emit(PostSuccessSavedState());
    } catch (e) {
      emit(PostError(e.toString()));
    }
  }

  Future<void> _onUnsavePost(UnsavePost event, Emitter<PostState> emit) async {
    try {
      emit(PostLoading());
      await usecases.unsavePost(event.postId);
      emit(PostunLikedState());
    } catch (e) {
      emit(PostError(e.toString()));
    }
  }

  Future<void> _onAddComment(AddComment event, Emitter<PostState> emit) async {
    try {
      emit(PostLoading());
      await usecases.addComment(AddCommentParams(postId: event.postId, comment: event.comment));
      emit(PostSuccesAddCommentState());
    } catch (e) {
      emit(PostError(e.toString()));
    }
  }

  Future<void> _onDeleteComment(DeleteComment event, Emitter<PostState> emit) async {
    try {
      emit(PostLoading());
      await usecases.deleteComment(DeleteCommentParams(postId: event.postId, commentId: event.commentId));
      emit(PostSuccessDeleteCommentState());
    } catch (e) {
      emit(PostError(e.toString()));
    }
  }

  Future<void> _onSharePost(SharePost event, Emitter<PostState> emit) async {
    try {
      emit(PostLoading());
      await usecases.sharePost(event.postId);
      emit(PostShareState());
    } catch (e) {
      emit(PostError(e.toString()));
    }
  }
}
