import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:socialapp/feature/post/domain/entities/entites.dart';
import 'package:socialapp/feature/post/presentation/bloc/post_bloc.dart';

class PostUi extends StatelessWidget {
  final Post post;

  const PostUi({super.key, 
    required this.post, 
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(child: BlocBuilder<PostBloc, PostState>(
      builder: (context, state) {
        if (state is PostLoadingState) {
          return const Center(child: CircularProgressIndicator());
        } else if (state is PostLoadedState) {
          return ListView.builder(
            itemCount: state.posts.length,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              return Container(
                margin: EdgeInsets.all(10),
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    // Rest of your code...
                    _FeedStats(
                      post: state.posts[index],
                    ),
                    _FeedCaption(
                      post: state.posts[index],
                      index: index,
                    ),
                    // Rest of your code...
                  ],
                ),
              );
            },
          );
        } else {
          return const Center(child: Text('No posts found'));
        }
      },
    ));
  }
}

class _FeedStats extends StatelessWidget {
  final Post post;

  const _FeedStats({
    required this.post,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      margin: EdgeInsets.symmetric(
        horizontal: 14,
      ),
      child: RichText(
        softWrap: true,
        overflow: TextOverflow.visible,
        text: TextSpan(
          children: [
            TextSpan(
              text: post.friendlist == null
                  ? '${post.likes} likes'
                  : 'Liked by $post.friendList and ${post.likes} others',
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}

class _FeedCaption extends StatelessWidget {
  final Post post;
  final int index;

  const _FeedCaption({
    required this.post,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Container(
          width: MediaQuery.of(context).size.width,
          margin: EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 5,
          ),
          child: RichText(
            softWrap: true,
            overflow: TextOverflow.visible,
            text: TextSpan(
              children: [
                TextSpan(
                  text: post.username,
                  style: TextStyle(
                      fontWeight: FontWeight.bold, color: Colors.black),
                ),
                TextSpan(
                  text: " ${post.caption}",
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
          ),
        ),
        Container(
          margin: EdgeInsets.symmetric(
            horizontal: 14,
          ),
          alignment: Alignment.topLeft,
          child: Text(
            "February 2020",
            textAlign: TextAlign.start,
            style: TextStyle(
              color: Colors.grey,
            ),
          ),
        ),
      ],
    );
  }
}