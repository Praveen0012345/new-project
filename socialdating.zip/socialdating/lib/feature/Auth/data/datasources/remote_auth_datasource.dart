import 'package:firebase_auth/firebase_auth.dart';
import 'package:socialapp/core/error/failureas.dart';


class RemoteAuthDatasource {

  final FirebaseAuth _firebaseAuth;
  String?_lastverificationId;
   int? _resendToken;
  RemoteAuthDatasource(this._firebaseAuth ,); 

  Future<void> sendOTP(String phoneNumber) async {
    await _firebaseAuth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (credential) {},
      verificationFailed: (exception) {
        throw ServerFailure(exception.message ?? "Verification failed");
      },
      codeSent: (verificationId, resendToken) {
       _lastverificationId = verificationId;
       _resendToken = resendToken;
      },
      codeAutoRetrievalTimeout: (verificationId) {},
    );
  }

  Future<void> verifyOtp(String verificationId, String smsCode) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    await _firebaseAuth.signInWithCredential(credential);
  }

  Future<void> resendOtp(String phoneNumber) async {
  
  if (_resendToken == null) {
      throw ServerFailure("Resend token is not available. Please send the OTP first.");
    }
     await _firebaseAuth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      timeout: const Duration(seconds: 60),
      forceResendingToken: _resendToken, // Use the stored resend token
      verificationCompleted: (credential) {
        // Auto-verification callback
      },
      verificationFailed: (exception) {
        throw ServerFailure(exception.message ?? "Resending OTP failed");
      },
      codeSent: (verificationId, resendToken) {
        _lastverificationId = verificationId; // Update the verificationId
        _resendToken = resendToken; // Update the resend token
      },
      codeAutoRetrievalTimeout: (verificationId) {
        _lastverificationId = verificationId;
      },
    );
  }

}


