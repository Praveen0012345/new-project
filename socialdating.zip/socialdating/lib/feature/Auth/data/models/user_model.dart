import 'package:socialapp/feature/Auth/domain/entities/user.dart';

class UserModel extends User {
  UserModel({required super.id, required super.phoneNumber});

}