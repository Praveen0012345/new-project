import 'package:socialapp/feature/Auth/data/datasources/remote_auth_datasource.dart';
import 'package:socialapp/feature/Auth/domain/repositories/AuthRepositories.dart';

class AuthrepositoryImp implements AuthRepository {
  final RemoteAuthDatasource remoteAuthDatasource;

  AuthrepositoryImp(this.remoteAuthDatasource);

  @override
  Future<void> sendOTP(String phoneNumber) {
    return remoteAuthDatasource.sendOTP(phoneNumber);
  }

  @override
  Future<void> verifyOTP(String verificationId, String smsCode) {
    return remoteAuthDatasource.verifyOtp(verificationId, smsCode);
  }

  @override
  Future<void> resendOtp(String phoneNumber) {
    return remoteAuthDatasource.resendOtp(phoneNumber);
  }
}
