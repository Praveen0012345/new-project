import 'package:flutter/material.dart';

class ElevetedAuth extends StatelessWidget {
  final String buttonText;
  final VoidCallback onPressed;
  final Color? color;
  // final bool isLoding;
  // final FormFieldValidator;
  const ElevetedAuth(
      {super.key,
      required this.buttonText,
      required this.onPressed,
      required this.color, 
      // required this.isLoding,
      
      // required this.FormFieldValidator,
      });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        // gradient: const LinearGradient(
        //   colors: color,
        //   begin: Alignment.bottomLeft,
        //   end: Alignment.topLeft,
        // ),
        color: color,
        borderRadius: BorderRadius.circular(25),
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          fixedSize: const Size(395, 55),
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
        ),
        onPressed: onPressed,
        child: Text(
          buttonText,
          style: const TextStyle(
              fontSize: 25, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      ),
    );
  }
}
