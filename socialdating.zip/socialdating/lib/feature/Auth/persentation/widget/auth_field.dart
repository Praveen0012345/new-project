import 'package:flutter/material.dart';
import 'package:socialapp/core/theme/app_pallete.dart';


class AuthField extends StatelessWidget {
  final String hinttext;
  final TextEditingController controller;
  final bool isObscureText;
  final Widget? prifixIcon;

  const AuthField({
    super.key,
    required this.hinttext,
    required this.controller,
    this.isObscureText = false, 
    this.prifixIcon, 
     

  });
  @override
  Widget build(BuildContext context) {
    return // todo: size of authfield
        SizedBox(
      height: 70,
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          prefixIcon: prifixIcon,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(25),
            borderSide: const BorderSide(
              color: Colors.grey,
              width: 4,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: AppPallete.eleveteduth,
              width: 1,
            ),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: Colors.red,
              width: 1,
            ),
          ),
          hintText: hinttext,
        ),
        validator: (value) {
          if (value!.isEmpty) {
            return "$hinttext is missing!";
          }
          return null;
        },
        obscureText: isObscureText,

        // if yo want to change the obscure
        // obscuringCharacter: ,
      ),
    );
  }
}
