part of 'auth_bloc.dart';

@immutable
sealed class AuthState {}

final class AuthInitial extends AuthState {}

class AuthLoadingState extends AuthState {}

class OtpSendState extends AuthState {}

class OtpVerifyState extends AuthState {}

class OtpErrorState extends AuthState{
  final String error;
   OtpErrorState({required this.error});
}

class AuthError extends AuthState {
  final String message;
  AuthError(this.message);
}
