// ignore_for_file: public_member_api_docs, sort_constructors_first
part of 'auth_bloc.dart';

@immutable
abstract class AuthEvent {}

class SendOtpEvent extends AuthEvent {
  final String phoneNumber;
  final String phoneCode;
  SendOtpEvent(
     this.phoneNumber, 
     this.phoneCode,
  );
}

class VerifyOtpEvent extends AuthEvent {
  final String smsCode;
  final String verificationId;
VerifyOtpEvent({required this.smsCode,required this.verificationId});
}
