import 'package:bloc/bloc.dart';

import 'package:meta/meta.dart';
import 'package:socialapp/feature/Auth/domain/usecases/send_otp.dart';
import 'package:socialapp/feature/Auth/domain/usecases/verify_otp.dart';

part 'auth_event.dart';
part 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final SendOTP sendOtpUseCase;
  final VerifyOTP verifyOtpUseCase;

  AuthBloc({
    required this.sendOtpUseCase,
    required this.verifyOtpUseCase,
  }) : super(AuthInitial()) {
    on<SendOtpEvent>((event, emit) async {
      emit(AuthLoadingState());
      try {
        await sendOtpUseCase(event.phoneNumber);
        emit(OtpSendState());
      } catch (e) {
        emit(AuthError(e.toString()));
      }
    });

    on<VerifyOtpEvent>((event, emit) async {
      emit(AuthLoadingState());
      try {
        await verifyOtpUseCase(event.verificationId, event.smsCode);
        emit(OtpVerifyState());
      } catch (e) {
        emit(AuthError(e.toString()));
      }
    });
  }
}
