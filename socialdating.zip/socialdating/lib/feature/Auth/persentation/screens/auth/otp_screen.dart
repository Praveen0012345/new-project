import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/style.dart';
import 'package:socialapp/core/theme/app_pallete.dart';
import 'package:socialapp/feature/Auth/persentation/bloc/auth_bloc.dart';
import 'package:socialapp/feature/Auth/persentation/screens/start/making_account.dart';
import 'package:socialapp/feature/Auth/persentation/widget/eleveted_auth.dart';

class OtpScreen extends StatefulWidget {
  const OtpScreen({super.key});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  String? otp;

  final _otpcontroller = OtpFieldController();

  final _formkey = GlobalKey<FormState>();

  // Telephony telephony = Telephony.instance;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(),
      body: SafeArea(
          child: Center(
        child: Padding(
          padding: EdgeInsets.all(18),
          child: BlocListener<AuthBloc, AuthState>(
            listener: (context, state) {
              if (State is OtpVerifyState) {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => MakingAccount()));
              } else if (state is OtpErrorState) {}
            },
            child: Form(
              key: _formkey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  const Text(
                    'Enter the confirmation code',
                    style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        color: AppPallete.eleveteduth),
                  ),
                  const SizedBox(
                    height: 3,
                  ),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "We have sent the code to your mobile number",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            color: Colors.black),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 40,
                  ),
                  SizedBox(
                    height: 70,
                    child: OTPTextField(
                      outlineBorderRadius: 10,
                      controller: _otpcontroller,
                      length: 6,
                      width: MediaQuery.of(context).size.width,
                      fieldWidth: 50,
                      style: const TextStyle(fontSize: 40),
                      textFieldAlignment: MainAxisAlignment.spaceAround,
                      fieldStyle: FieldStyle.box,
                      onCompleted: (pin) {
                        otp = pin;
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 60,
                  ),
                  ElevetedAuth(
                      buttonText: "submit otp",
                      onPressed: () {
                        if (_formkey.currentState!.validate()) {
                          context.read<AuthBloc>().add(VerifyOtpEvent(
                                smsCode:otp?? "", 
                                verificationId: '',
                              ));
                        }
                      },
                      color: AppPallete.eleveteduth),
                  const SizedBox(
                    height: 10,
                  ),
                  GestureDetector(
                    onTap: () {
                      // Navigate to Sign Up
                    },
                    child: const Text.rich(
                      TextSpan(
                        text: "Don't receive the OTP? ",
                        style: TextStyle(
                            fontSize: 21, fontWeight: FontWeight.w500),
                        children: [
                          TextSpan(
                            text: 'Resnd OTP',
                            style: TextStyle(
                              color: AppPallete.eleveteduth,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      )),
    );
  }
}
