import 'package:flutter/material.dart';
import 'package:socialapp/core/theme/app_pallete.dart';
import 'package:socialapp/feature/Auth/persentation/screens/auth/forget_password.dart';
import 'package:socialapp/feature/Auth/persentation/screens/auth/sign_up.dart';
import 'package:socialapp/feature/Auth/persentation/widget/auth_field.dart';
import 'package:socialapp/feature/Auth/persentation/widget/eleveted_auth.dart';


class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _usernameController = TextEditingController();
  final _passwoardController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  @override
  void dispose() {
    _usernameController.dispose();
    _passwoardController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(),
      body: SafeArea(
          child: Center(
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Image.asset("assets/png/icon_png.png"),
              const SizedBox(
                height: 50,
              ),
              AuthField(hinttext: "Username", controller: _usernameController,  ),
              const SizedBox(
                height: 10,
              ),
              AuthField(
                hinttext: "password",
                controller: _passwoardController,
                isObscureText: true,
              ),
              const SizedBox(
                height: 6,
              ),
              Row(
                children: <Widget>[
                  Checkbox(value: false, onChanged: (value) {}),
                  const SizedBox(
                    width: 1,
                  ),
                  const Text(
                    'Remember me',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(
                    width: 100,
                  ),
                  GestureDetector(
                    onTap: () {
                      //TODO : navigate it on forget password page
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const ForgetPassword()));
                    },
                    child: const Text(
                      "Forget Password?",
                      style: TextStyle(
                          color: AppPallete.eleveteduth,
                          fontWeight: FontWeight.bold),
                    ),
                  )
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              ElevetedAuth(
                  buttonText: 'Login',
                  onPressed: () {},
                  color: AppPallete.eleveteduth),
              const SizedBox(
                height: 10,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const SignUp()));
                },
                child: const Text.rich(
                  TextSpan(
                    text: "New user? ",
                    style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w500,
                        color: Colors.black),
                    children: [
                      TextSpan(
                        text: 'Sign Up',
                        style: TextStyle(
                          color: AppPallete.eleveteduth,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      )),
    );
  }
}
