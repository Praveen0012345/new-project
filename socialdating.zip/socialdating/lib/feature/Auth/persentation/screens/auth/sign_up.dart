import 'package:country_picker/country_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:socialapp/core/theme/app_pallete.dart';
import 'package:socialapp/feature/Auth/persentation/bloc/auth_bloc.dart';
import 'package:socialapp/feature/Auth/persentation/screens/auth/otp_screen.dart';
import 'package:socialapp/feature/Auth/persentation/widget/auth_field.dart';
import 'package:socialapp/feature/Auth/persentation/widget/eleveted_auth.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  final _phonenumberController = TextEditingController();
  final formKey = GlobalKey<FormState>();
  Country? _selectedCountry;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(13.0),
          child: BlocListener<AuthBloc, AuthState>(
            listener: (context, state) {
              if (state is OtpSendState) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const OtpScreen()),
                );
              } else if (state is AuthError) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(state.message)),
                );
              }
            },
            child: Form(
              key: formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Image.asset("assets/png/icon_logo.png"),
                  const SizedBox(height: 50),
                  const Text(
                    "Let's get started...",
                    style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "What's your mobile number?",
                    style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "Enter your mobile number where you can be contacted and",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                  const SizedBox(height: 3),
                  const Text(
                    "no one will see this on your profile.",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                  const SizedBox(height: 15),
                  AuthField(
                    hinttext: "Enter your number",
                    controller: _phonenumberController,
                    prifixIcon: InkWell(
                      onTap: () {
                        showCountryPicker(
                          context: context,
                          onSelect: (Country country) {
                            setState(() {
                              _selectedCountry = country;
                            });
                          },
                        );
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.flag, // Dropdown indicator icon
                              size: 24.0,
                              color: Colors.black,
                            ),
                            const SizedBox(
                              width: 8,
                            ),
                            if (_selectedCountry != null)
                              Text(
                                "+${_selectedCountry!.phoneCode}",
                                style: const TextStyle(fontSize: 16),
                              )
                            else
                              const Text(
                                "+",
                                style: TextStyle(fontSize: 16),
                              ),
                            const SizedBox(width: 8),
                            if (_selectedCountry != null)
                              Text(
                                _selectedCountry!.flagEmoji,
                                style: const TextStyle(fontSize: 16),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 1),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(
                          'You may receive SMS notifications for security and login purposes.',
                          style: TextStyle(
                              fontSize: 12, fontWeight: FontWeight.normal),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 25),
                  ElevetedAuth(
                    buttonText: "Next",
                    onPressed: () {
                      TODO: // send otp
                      if (formKey.currentState!.validate()) {
                         if(_selectedCountry != null){
                          context.read<AuthBloc>().add(SendOtpEvent(
                              _phonenumberController.text,
                              _selectedCountry!.phoneCode,
                          ));
                        }else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text("Please select a country code."),
                            ),
                          );
                        }
                      }
                    },
                    color: AppPallete.eleveteduth,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
