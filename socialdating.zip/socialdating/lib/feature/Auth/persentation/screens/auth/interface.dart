import 'package:flutter/material.dart';
import 'package:socialapp/core/theme/app_pallete.dart';
import 'package:socialapp/feature/Auth/persentation/screens/auth/login_page.dart';
import 'package:socialapp/feature/Auth/persentation/screens/auth/sign_up.dart';
import 'package:socialapp/feature/Auth/persentation/widget/eleveted_auth.dart';

class Interface extends StatelessWidget {
  const Interface({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Hello!',
              style: TextStyle(
                fontSize: 50,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 21),
            const Text(
              'Welcome to Meet',
              style: TextStyle(fontSize: 26),
            ),
            const SizedBox(height: 32),
            ElevetedAuth(
                buttonText: "signup",
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const SignUp()));
                },
                color: AppPallete.eleveteduth),
            const SizedBox(height: 12),
            ElevetedAuth(
                buttonText: "login",
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const LoginPage()));
                },
                color: AppPallete.eleveteduth),
            const SizedBox(
              height: 15,
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "or signup",
                  style: TextStyle(
                      fontSize: 25, color: AppPallete.backgroundColor),
                ),
              ],
            ),
            const SizedBox(
              height: 15,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppPallete.eleveteduth,
                  ),
                  child: const Icon(Icons.facebook, color: Colors.white),
                ),
                SizedBox(
                  width: 5,
                ),
                Container(
                  width: 50,
                  height: 50,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppPallete.eleveteduth,
                  ),
                  child: const Icon(Icons.apple, color: Colors.white),
                ),
                SizedBox(
                  width: 5,
                ),
                Container(
                  width: 50,
                  height: 50,
                  decoration: const BoxDecoration(
                      shape: BoxShape.circle, color: AppPallete.eleveteduth),
                  child: const Icon(Icons.dangerous, color: Colors.white),
                ),
              ],
            ),
            const SizedBox(
              height: 15,
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => const SignUp()));
              },
              child: RichText(
                text: TextSpan(
                    text: "Dont't have acoount?  ",
                    style: Theme.of(context).textTheme.titleMedium,
                    children: [
                      TextSpan(
                        text: "Sign Up",
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  color: AppPallete.eleveteduth,
                                  fontWeight: FontWeight.bold,
                                ),
                      )
                    ]),
              ),
            )
          ],
        ),
      ),
    );
  }
}
