import 'package:flutter/material.dart';
import 'package:socialapp/core/theme/app_pallete.dart';
import 'package:socialapp/feature/Auth/persentation/screens/start/face_verification.dart';
import 'package:socialapp/feature/Auth/persentation/widget/auth_field.dart';
import 'package:socialapp/feature/Auth/persentation/widget/eleveted_auth.dart';


class MakingAccount extends StatefulWidget {
  const MakingAccount({super.key});

  @override
  State<MakingAccount> createState() => _MakingAccountState();
}

class _MakingAccountState extends State<MakingAccount> {
  final _dateofbirthController = TextEditingController();
  final _employedcivilController = TextEditingController();
  final _nameController = TextEditingController();
  final _workcivilController = TextEditingController();
  final formKey = GlobalKey<FormState>();
  bool loading = false;

  @override
  void dispose() {
    _nameController.dispose();
    _dateofbirthController.dispose();
    _workcivilController.dispose();
    _employedcivilController.dispose();
    super.dispose();
  }

  void _submitForm() {
    if (formKey.currentState!.validate()) {
      // Create a Map to store the data
      Map<String, String> formData = {
        "full_name": _nameController.text.trim(),
        "date_of_birth": _dateofbirthController.text.trim(),
        "employed_in_civil": _employedcivilController.text.trim(),
        "civil_sector": _workcivilController.text.trim(),
      };

      // Print the Map to confirm data (replace this with your DB save logic)
      print("Form Data: $formData");

      // Navigate to the next screen
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const FaceVerification()),
      );
    } else {
      print("Form validation failed");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(
                    height: 80,
                  ),
                  const Text(
                    "Lets's get start...",
                    style: TextStyle(
                        fontSize: 40,
                        fontWeight: FontWeight.bold,
                        color: AppPallete.eleveteduth),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  const Text(
                    "your full name",
                    style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.bold,
                        color: AppPallete.eleveteduth),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  AuthField(
                    hinttext: "enter your name ",
                    controller: _nameController, 
                    
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    "your full DOB",
                    style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w500,
                        color: AppPallete.eleveteduth),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  AuthField(
                    hinttext: "enter your DOB",
                    controller: _dateofbirthController, 
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    "are you employed in civil sector",
                    style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w500,
                        color: AppPallete.eleveteduth),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  AuthField(
                    hinttext: "please enter yes/no",
                    controller: _employedcivilController, 
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    "which civil sector are you working in",
                    style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w500,
                        color: AppPallete.eleveteduth),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  AuthField(
                    hinttext: "eg. indian police service",
                    controller: _workcivilController, 
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  ElevetedAuth(
                    buttonText: "submit",
                    onPressed: _submitForm,
                    color: AppPallete.eleveteduth,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
