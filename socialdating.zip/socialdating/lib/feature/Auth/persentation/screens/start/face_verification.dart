import 'package:flutter/material.dart';

class FaceVerification extends StatefulWidget {
  const FaceVerification({super.key});

  @override
  State<FaceVerification> createState() => _FaceVerificationState();
}

class _FaceVerificationState extends State<FaceVerification> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
    );
  }
}
