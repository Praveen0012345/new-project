class User {
  final String id;
  final String phoneNumber;

  User({required this.id, required this.phoneNumber});
}
