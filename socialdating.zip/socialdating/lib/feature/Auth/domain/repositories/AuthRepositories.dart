abstract class AuthRepository {
  Future<void> sendOTP(String phoneNumber);
  Future<void> verifyOTP(String verificationId, String smsCode);
   Future<void> resendOtp(String phoneNumber);
}