

import 'package:socialapp/feature/Auth/domain/repositories/AuthRepositories.dart';

class SendOTP {
  final AuthRepository repository;

  SendOTP(this.repository);

  Future<void> call(String phoneNumber) {
    return repository.sendOTP(phoneNumber);
  }
}
