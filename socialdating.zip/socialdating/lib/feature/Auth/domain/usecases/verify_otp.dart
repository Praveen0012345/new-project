
import 'package:socialapp/feature/Auth/domain/repositories/AuthRepositories.dart';

class VerifyOTP {
  final AuthRepository repository;

  VerifyOTP(this.repository);

  Future<void> call(String verificationId, String smsCode) {
    return repository.verifyOTP(verificationId, smsCode);
  }
}
