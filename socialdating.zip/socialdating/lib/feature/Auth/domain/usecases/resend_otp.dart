import 'package:socialapp/feature/Auth/domain/repositories/AuthRepositories.dart';

class ResendOtp {
  final AuthRepository authRepository;
  ResendOtp(this.authRepository);
  Future<void> resedOtp(String phoneNumber) async {
    return authRepository.resendOtp(phoneNumber);
  }
}
